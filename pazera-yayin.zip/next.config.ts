import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Migration SQL and its journal must be available to the production server.
  outputFileTracingIncludes: {
    "/*": ["./drizzle/**/*"],
  },
  async redirects() {
    return [
      { source: "/hizmetler/dis-ticaret-operasyonu", destination: "/hizmetler/ihracat-surec-danismanligi", permanent: false },
      { source: "/hizmetler/alici-gelistirme", destination: "/hizmetler/alici-bulma", permanent: false },
      { source: "/hizmetler/marka-ve-dijital-ihracat", destination: "/hizmetler/web-site-tasarimi", permanent: false },
      { source: "/hizmetler/ihracat-stratejisi", destination: "/hizmetler/ihracat-surec-danismanligi", permanent: false },
      { source: "/hizmetler/tesvik-hibe-danismanligi", destination: "/hizmetler", permanent: false },
      { source: "/bilgi-merkezi/ihracat-tesvikleri-rehberi", destination: "/bilgi-merkezi", permanent: false },
      { source: "/bilgi-merkezi/2026-ihracat-pazarlari", destination: "/bilgi-merkezi/uc-ofis-uc-pazar", permanent: false },
      { source: "/bilgi-merkezi/alici-bulma-rehberi", destination: "/bilgi-merkezi", permanent: false },
      { source: "/bilgi-merkezi/inci-terms-2020-secimi", destination: "/bilgi-merkezi/lojistik-nakliye-maliyetleri", permanent: false },
    ];
  },
};

export default nextConfig;
