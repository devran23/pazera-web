"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function AdminLogout() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function logout() {
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/admin/logout", { method: "POST" });
      if (!response.ok) throw new Error();
      router.refresh();
    } catch {
      setError("Çıkış yapılamadı.");
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col items-end gap-1">
      <button type="button" onClick={logout} disabled={busy} className="btn btn-light disabled:opacity-60">{busy ? "Çıkış…" : "Panelden çıkış"}</button>
      {error && <span role="alert" className="text-xs text-paper/70">{error}</span>}
    </div>
  );
}
