"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { packages } from "@/content/site";

export type PanelLead = {
  id: number;
  name: string;
  company: string | null;
  email: string;
  phone: string | null;
  country: string | null;
  service: string | null;
  packageName: string | null;
  volume: string | null;
  message: string | null;
  source: string;
  status: string;
  createdAt: string;
};

const STATUS_OPTIONS = [
  { value: "yeni", label: "Yeni" },
  { value: "gorusuluyor", label: "Görüşülüyor" },
  { value: "teklif", label: "Teklif" },
  { value: "kazanildi", label: "Kazanıldı" },
  { value: "arsiv", label: "Arşiv" },
];

const STATUS_STYLES: Record<string, string> = {
  yeni: "border-copper/40 bg-copper/10 text-copper-dark",
  gorusuluyor: "border-forest/30 bg-forest/10 text-forest",
  teklif: "border-amber-700/30 bg-amber-600/10 text-amber-800",
  kazanildi: "border-emerald-700/30 bg-emerald-600/10 text-emerald-800",
  arsiv: "border-ink/20 bg-ink/5 text-ink/50",
};

function formatDate(iso: string) {
  return new Intl.DateTimeFormat("tr-TR", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(iso));
}

export function LeadTable({ leads }: { leads: PanelLead[] }) {
  const router = useRouter();
  const [pendingId, setPendingId] = useState<number | null>(null);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [, startTransition] = useTransition();

  async function updateStatus(id: number, status: string) {
    setPendingId(id);
    setError("");
    try {
      const res = await fetch(`/api/leads/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
      if (!res.ok) {
        const data = (await res.json()) as { error?: string };
        setError(data.error ?? "Durum güncellenemedi.");
        return;
      }
      startTransition(() => router.refresh());
    } catch {
      setError("Bağlantı hatası.");
    } finally {
      setPendingId(null);
    }
  }

  if (leads.length === 0) {
    return <div className="rounded-md border border-dashed border-ink/20 bg-paper px-6 py-16 text-center"><p className="display text-2xl text-ink">Henüz talep yok</p><p className="mx-auto mt-2 max-w-sm text-sm text-ink/55">İletişim formu doldurulduğunda talepler burada listelenir.</p></div>;
  }

  return (
    <div className="space-y-3">
      {error && <p role="alert" className="rounded-md border border-copper/30 bg-copper/5 px-4 py-2 text-xs text-copper-dark">{error}</p>}
      <div className="overflow-hidden rounded-md border border-ink/12 bg-paper">
        <div className="hidden grid-cols-[1.4fr_1.4fr_1fr_0.9fr_0.9fr] gap-4 border-b border-ink/12 bg-bone/60 px-5 py-3 text-[0.625rem] uppercase tracking-[0.14em] text-ink/45 lg:grid"><span>Kişi / Firma</span><span>İletişim</span><span>Hizmet / Paket</span><span>Tarih</span><span>Durum</span></div>
        {leads.map((lead) => {
          const pkg = packages.find((item) => item.id === lead.packageName);
          return (
            <div key={lead.id} className="border-b border-ink/10 last:border-b-0">
              <div className="grid gap-4 px-5 py-4 lg:grid-cols-[1.4fr_1.4fr_1fr_0.9fr_0.9fr] lg:items-center">
                <div><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-semibold text-ink">{lead.name}</p><span className={`border px-1.5 py-0.5 text-[0.5rem] uppercase tracking-[0.1em] ${STATUS_STYLES[lead.status] ?? STATUS_STYLES.yeni}`}>{STATUS_OPTIONS.find((option) => option.value === lead.status)?.label ?? lead.status}</span></div><p className="mt-0.5 text-xs text-ink/50">{lead.company ?? "Firma belirtilmedi"}</p></div>
                <div className="text-xs leading-relaxed text-ink/60"><a href={`mailto:${lead.email}`} className="block hover:text-copper-dark">{lead.email}</a>{lead.phone && <span className="block">{lead.phone}</span>}{lead.country && <span className="block text-ink/45">Pazar: {lead.country}</span>}</div>
                <div className="text-xs text-ink/60"><p>{lead.service ?? "Hizmet belirtilmedi"}</p><p className="mt-0.5 font-semibold text-copper-dark">{pkg ? `Paket: ${pkg.name}` : "Tek hizmet / belirsiz"}</p><p className="mt-0.5 text-ink/40">{lead.volume ?? "Durum belirtilmedi"}</p></div>
                <p className="text-xs text-ink/45">{formatDate(lead.createdAt)}</p>
                <div className="flex items-center gap-2"><select aria-label={`${lead.name} talebinin durumu`} value={lead.status} disabled={pendingId === lead.id} onChange={(event) => updateStatus(lead.id, event.target.value)} className="w-full rounded border border-ink/20 bg-paper px-2 py-1.5 text-xs text-ink focus:border-copper focus:outline-none disabled:opacity-60">{STATUS_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select><button type="button" onClick={() => setExpanded(expanded === lead.id ? null : lead.id)} aria-expanded={expanded === lead.id} className="shrink-0 rounded border border-ink/15 px-2 py-1.5 text-[0.625rem] uppercase tracking-[0.1em] text-ink/55 hover:border-ink/40">{expanded === lead.id ? "Kapat" : "Not"}</button></div>
              </div>
              {expanded === lead.id && <div className="border-t border-ink/10 bg-bone/50 px-5 py-4"><p className="text-[0.625rem] uppercase tracking-[0.14em] text-ink/40">Talep notu · kaynak: {lead.source}</p><p className="mt-2 max-w-3xl text-sm leading-relaxed text-ink/70">{lead.message ?? "Not girilmedi."}</p><a href={`mailto:${lead.email}?subject=${encodeURIComponent("Pazera · Görüşme talebi")}`} className="btn btn-dark mt-4 !py-2.5 !text-[0.625rem]">E-posta ile yanıtla</a></div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
