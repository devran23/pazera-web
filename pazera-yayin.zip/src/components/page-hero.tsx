import Link from "next/link";
import type { ReactNode } from "react";

export function PageHero({
  label,
  title,
  intro,
  breadcrumb,
  children,
}: {
  label: string;
  title: ReactNode;
  intro?: string;
  breadcrumb?: { label: string; href?: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-ink/10 bg-bone">
      <div
        className="absolute -right-24 -top-32 h-[420px] w-[420px] rounded-full bg-sand/40 blur-[90px]"
        aria-hidden="true"
      />
      <div className="wrap relative py-12 md:py-16">
        {breadcrumb && breadcrumb.length > 0 && (
          <nav aria-label="Sayfa yolu" className="mb-8 flex flex-wrap items-center gap-2 text-xs text-ink/45">
            <Link href="/" className="transition-colors hover:text-copper">
              Ana sayfa
            </Link>
            {breadcrumb.map((item) => (
              <span key={item.label} className="flex items-center gap-2">
                <span className="text-ink/25">/</span>
                {item.href ? (
                  <Link href={item.href} className="transition-colors hover:text-copper">
                    {item.label}
                  </Link>
                ) : (
                  <span className="text-ink/70">{item.label}</span>
                )}
              </span>
            ))}
          </nav>
        )}

        <div className="grid gap-8 lg:grid-cols-[1.25fr_0.75fr] lg:items-end lg:gap-16">
          <div>
            <p className="eyebrow text-copper">{label}</p>
            <h1 className="display mt-5 text-[clamp(2.4rem,5.2vw,4.2rem)] text-ink">{title}</h1>
          </div>
          <div>{children ?? (intro && <p className="text-sm leading-relaxed text-ink/60">{intro}</p>)}</div>
        </div>
      </div>
    </section>
  );
}
