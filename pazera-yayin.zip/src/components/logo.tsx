import Link from "next/link";
import { site } from "@/content/site";

export function Logo({ full = false }: { tone?: "ink" | "light"; full?: boolean }) {
  if (full) {
    return (
      <Link href="/" aria-label="Pazera ana sayfa" className="inline-block">
        <img src={site.logo} alt="Pazera Dış Ticaret — Dünyaya Açılan Ticaret Kapınız" width={260} height={177} className="h-auto w-[220px] sm:w-[260px]" />
      </Link>
    );
  }

  return (
    <Link href="/" className="group flex shrink-0 items-center gap-3" aria-label="Pazera ana sayfa">
      <img src={site.mark} alt="" width={48} height={48} className="h-11 w-11 transition-transform duration-500 group-hover:rotate-6 sm:h-12 sm:w-12" />
      <span className="flex flex-col leading-none">
        <span className="text-[1.35rem] font-semibold tracking-[0.18em] text-copper sm:text-[1.5rem]">PAZERA</span>
        <span className="mt-1.5 text-[0.5rem] font-semibold uppercase tracking-[0.42em] text-paper/65">Dış Ticaret</span>
      </span>
    </Link>
  );
}
