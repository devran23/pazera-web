"use client";

import Link from "next/link";
import { useState } from "react";
import { services } from "@/content/site";

type Option = { label: string; score: number };
type Question = {
  id: string;
  title: string;
  question: string;
  options: Option[];
  serviceSlug: string;
  action: string;
};

const QUESTIONS: Question[] = [
  {
    id: "product",
    title: "Ürün & fiyat",
    question: "Ürününüzün hedef pazardaki rakip fiyatlarla karşılaştırmasını yaptınız mı?",
    options: [
      { label: "Henüz yapmadık", score: 0 },
      { label: "Genel bir fikrimiz var", score: 1 },
      { label: "Bir kez çalıştık, güncel değil", score: 2 },
      { label: "Düzenli olarak güncelliyoruz", score: 3 },
    ],
    serviceSlug: "pazar-arastirmasi",
    action: "Rakip fiyat ve konumlandırma çalışması",
  },
  {
    id: "market",
    title: "Hedef pazar",
    question: "Hedef pazarlarınız veriyle mi belirlendi?",
    options: [
      { label: "Henüz bir hedef seçmedik", score: 0 },
      { label: "Fuarlardan ve tavsiyelerden", score: 1 },
      { label: "Kendi araştırmamızla", score: 2 },
      { label: "İthalat verisi ve saha görüşmesiyle", score: 3 },
    ],
    serviceSlug: "pazar-arastirmasi",
    action: "Hedef pazar seçimi ve önceliklendirme",
  },
  {
    id: "compliance",
    title: "Belge & uyum",
    question: "İhracat için gereken sertifika ve belgeleriniz hangi durumda?",
    options: [
      { label: "Hangilerinin gerektiğini bilmiyoruz", score: 0 },
      { label: "Listeyi biliyoruz, süreç başlamadı", score: 1 },
      { label: "Bazıları tamam, bazıları eksik", score: 2 },
      { label: "Hedef pazarlar için tamamlanmış", score: 3 },
    ],
    serviceSlug: "ihracat-surec-danismanligi",
    action: "Sertifikasyon ve uyum yol haritası",
  },
  {
    id: "buyers",
    title: "Alıcı erişimi",
    question: "Doğrulanmış alıcı veya distribütör listeniz var mı?",
    options: [
      { label: "Hiç yok", score: 0 },
      { label: "Fuar listelerinden birkaç isim", score: 1 },
      { label: "Sınırlı sayıda doğrulanmış alıcı", score: 2 },
      { label: "Düzenli beslenen bir alıcı ağımız var", score: 3 },
    ],
    serviceSlug: "alici-bulma",
    action: "Alıcı geliştirme ve görüşme programı",
  },
  {
    id: "operations",
    title: "Operasyon & evrak",
    question: "Dış ticaret operasyonunuzu kim yürütüyor?",
    options: [
      { label: "Henüz kurulmadı", score: 0 },
      { label: "Tek kişi, ek görev olarak", score: 1 },
      { label: "Ayrı bir ihracat ekibi var", score: 2 },
      { label: "Kurulu süreç, kontrol listeleri ve yedekli", score: 3 },
    ],
    serviceSlug: "ihracat-surec-danismanligi",
    action: "Operasyon ve evrak süreç kurulumu",
  },
  {
    id: "brand",
    title: "Marka & dijital",
    question: "Hedef pazar dilinde marka ve dijital varlığınız var mı?",
    options: [
      { label: "Yalnızca Türkçe içeriklerimiz var", score: 0 },
      { label: "İngilizce katalog ve site", score: 1 },
      { label: "Ana pazar dilinde site, sosyal medya yok", score: 2 },
      { label: "Çok dilli marka varlığı ve pazaryeri hesapları", score: 3 },
    ],
    serviceSlug: "web-site-tasarimi",
    action: "Marka, ambalaj ve dijital görünürlük",
  },
];

const MAX = QUESTIONS.length * 3;

function levelFor(score: number) {
  if (score >= 80)
    return {
      label: "İhracata hazır",
      detail:
        "Temel altyapınız yerinde. Şimdi doğru alıcıyla görüşme ve ilk sevkiyatı hızlandırma zamanı.",
    };
  if (score >= 60)
    return {
      label: "Hazır, eksikler var",
      detail:
        "İyi bir noktadasınız. Birkaç başlığı tamamlayarak pazara giriş sürenizi kısaltabilirsiniz.",
    };
  if (score >= 35)
    return {
      label: "Gelişmekte",
      detail:
        "Altyapı kısmen var, ancak önceliklendirme eksik. Planlı bir 90 günlük programla hızla ilerleyebilirsiniz.",
    };
  return {
    label: "Başlangıç aşaması",
    detail:
      "Henüz yolun başındasınız. Sıralı bir hazırlık planıyla hatalı pazarlara yatırım yapmadan ilerleyebilirsiniz.",
  };
}

export function ReadinessQuiz() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [company, setCompany] = useState("");
  const [email, setEmail] = useState("");
  const [saveState, setSaveState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [saveMessage, setSaveMessage] = useState("");

  const total = Object.values(answers).reduce((sum, value) => sum + value, 0);
  const score = Math.round((total / MAX) * 100);
  const answeredAll = Object.keys(answers).length === QUESTIONS.length;
  const finished = answeredAll && step >= QUESTIONS.length;
  const level = levelFor(score);

  const weakest = QUESTIONS.reduce<Question | null>((worst, question) => {
    if (answers[question.id] === undefined) return worst;
    if (!worst) return question;
    return answers[question.id] < answers[worst.id] ? question : worst;
  }, null);

  const focusService = services.find((service) => service.slug === weakest?.serviceSlug);

  function choose(questionId: string, value: number) {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
    setStep((prev) => prev + 1);
  }

  function restart() {
    setAnswers({});
    setStep(0);
    setCompany("");
    setEmail("");
    setSaveState("idle");
    setSaveMessage("");
  }

  async function saveResult(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaveState("loading");
    try {
      const res = await fetch("/api/readiness", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          company,
          email,
          score,
          level: level.label,
          focus: weakest?.action ?? "",
          answers,
        }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok || !data.ok) {
        setSaveState("error");
        setSaveMessage(data.error ?? "Sonuç kaydedilemedi.");
        return;
      }
      setSaveState("success");
      setSaveMessage("Sonucunuz ekibimize iletildi. 1 iş günü içinde raporunuzu paylaşacağız.");
    } catch {
      setSaveState("error");
      setSaveMessage("Bağlantı hatası. Lütfen tekrar deneyin.");
    }
  }

  if (!finished) {
    const question = QUESTIONS[step];
    const progress = Math.round((step / QUESTIONS.length) * 100);

    return (
      <div className="border border-ink/12 bg-paper">
        <div className="border-b border-ink/12 px-6 py-5 sm:px-8">
          <div className="flex items-center justify-between text-[0.625rem] uppercase tracking-[0.16em] text-ink/45">
            <span>
              Soru {Math.min(step + 1, QUESTIONS.length)} / {QUESTIONS.length}
            </span>
            <span>{question?.title ?? "Sonuç"}</span>
          </div>
          <div className="mt-3 h-[3px] w-full bg-ink/10">
            <div
              className="h-full bg-copper transition-all duration-500"
              style={{ width: `${Math.max(progress, 3)}%` }}
            />
          </div>
        </div>

        {question ? (
          <div className="p-6 sm:p-9">
            <h2 className="display text-[clamp(1.6rem,2.8vw,2.2rem)] leading-snug text-ink">
              {question.question}
            </h2>
            <div className="mt-7 space-y-2.5">
              {question.options.map((option) => {
                const selected = answers[question.id] === option.score;
                return (
                  <button
                    key={option.label}
                    type="button"
                    onClick={() => choose(question.id, option.score)}
                    className={`flex w-full items-center justify-between gap-4 border px-5 py-4 text-left text-sm transition-all ${
                      selected
                        ? "border-copper bg-copper/10 text-ink"
                        : "border-ink/15 text-ink/75 hover:border-ink/40 hover:bg-bone/60"
                    }`}
                  >
                    <span>{option.label}</span>
                    <span
                      className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border text-[0.625rem] ${
                        selected ? "border-copper bg-copper text-paper" : "border-ink/20 text-ink/40"
                      }`}
                    >
                      →
                    </span>
                  </button>
                );
              })}
            </div>

            {step > 0 && (
              <button
                type="button"
                onClick={() => setStep((prev) => Math.max(0, prev - 1))}
                className="mt-6 text-xs uppercase tracking-[0.14em] text-ink/45 transition-colors hover:text-ink"
              >
                ← Önceki soru
              </button>
            )}
          </div>
        ) : (
          <div className="p-6 sm:p-9">
            <p className="text-sm text-ink/60">
              Tüm soruları yanıtladınız. Sonucu görmek için devam edin.
            </p>
            <button
              type="button"
              onClick={() => setStep(QUESTIONS.length)}
              className="btn btn-primary mt-5"
            >
              Sonucu göster
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="border border-ink/12 bg-paper">
      <div className="grid gap-0 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="bg-ink p-7 text-paper sm:p-9">
          <p className="eyebrow text-copper">Hazırlık skorunuz</p>
          <div className="mt-6 flex items-center gap-6">
            <div className="relative grid h-28 w-28 shrink-0 place-items-center">
              <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
                <circle cx="50" cy="50" r="42" fill="none" stroke="#fdfaf4" strokeOpacity="0.15" strokeWidth="6" />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="#b25f38"
                  strokeWidth="6"
                  strokeDasharray={2 * Math.PI * 42}
                  strokeDashoffset={2 * Math.PI * 42 * (1 - score / 100)}
                  strokeLinecap="round"
                  className="transition-all duration-700"
                />
              </svg>
              <span className="display text-4xl text-paper">{score}</span>
            </div>
            <div>
              <p className="eyebrow text-sage">Seviye</p>
              <p className="display mt-1 text-2xl text-paper">{level.label}</p>
              <p className="mt-2 text-xs leading-relaxed text-paper/55">{level.detail}</p>
            </div>
          </div>

          <div className="mt-8 space-y-3.5 border-t border-paper/15 pt-6">
            {QUESTIONS.map((question) => {
              const value = answers[question.id] ?? 0;
              const percent = Math.round((value / 3) * 100);
              return (
                <div key={question.id}>
                  <div className="flex items-center justify-between text-[0.6875rem] text-paper/60">
                    <span>{question.title}</span>
                    <span>{percent}%</span>
                  </div>
                  <div className="mt-1.5 h-[3px] w-full bg-paper/15">
                    <div className="h-full bg-copper transition-all duration-700" style={{ width: `${Math.max(percent, 2)}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="p-7 sm:p-9">
          <p className="eyebrow text-copper">Öncelikli başlık</p>
          <h2 className="display mt-3 text-[clamp(1.5rem,2.6vw,2rem)] leading-snug text-ink">
            {weakest?.action ?? "Hazırlık planı"}
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-ink/60">
            {score >= 80
              ? "Altyapınız güçlü görünüyor. Bir sonraki adım, hedef pazarda doğrulanmış alıcı görüşmeleri kurmak."
              : "Skor dağılımınıza göre en düşük alanda hızlı bir iyileştirme, toplam hazırlığı en çok yükseltecek adım."}
          </p>

          {focusService && (
            <Link
              href={`/hizmetler/${focusService.slug}`}
              className="mt-5 flex items-center justify-between gap-4 border border-ink/15 px-5 py-4 transition-colors hover:border-copper/50 hover:bg-bone/50"
            >
              <div>
                <p className="text-[0.625rem] uppercase tracking-[0.14em] text-copper">Önerilen hizmet</p>
                <p className="mt-1 text-sm font-semibold text-ink">{focusService.title}</p>
              </div>
              <span aria-hidden="true">→</span>
            </Link>
          )}

          {saveState === "success" ? (
            <div className="mt-6 border border-forest/25 bg-forest/5 p-5">
              <p className="text-sm font-semibold text-forest">Teşekkürler, kaydedildi.</p>
              <p className="mt-1.5 text-sm leading-relaxed text-ink/65">{saveMessage}</p>
              <Link href="/iletisim" className="btn btn-dark mt-4">
                Ayrıntılı görüşme planla
              </Link>
            </div>
          ) : (
            <form onSubmit={saveResult} className="mt-6 border-t border-ink/12 pt-6">
              <p className="text-sm font-semibold text-ink">Raporu e-postanıza gönderelim</p>
              <p className="mt-1.5 text-xs leading-relaxed text-ink/55">
                Skorunuzu ve öncelikli aksiyon listesini ekibimiz kişiselleştirerek paylaşır.
              </p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="quiz-company">
                    Firma
                  </label>
                  <input
                    id="quiz-company"
                    className="field"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Firma adı"
                  />
                </div>
                <div>
                  <label className="label" htmlFor="quiz-email">
                    E-posta *
                  </label>
                  <input
                    id="quiz-email"
                    type="email"
                    required
                    className="field"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ad@firma.com"
                  />
                </div>
              </div>
              {saveState === "error" && (
                <p role="alert" className="mt-3 text-xs text-copper">
                  {saveMessage}
                </p>
              )}
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  type="submit"
                  disabled={saveState === "loading"}
                  className="btn btn-primary disabled:opacity-60"
                >
                  {saveState === "loading" ? "Kaydediliyor…" : "Raporu gönder"}
                </button>
                <button
                  type="button"
                  onClick={restart}
                  className="text-xs uppercase tracking-[0.14em] text-ink/45 hover:text-ink"
                >
                  Baştan başla
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
