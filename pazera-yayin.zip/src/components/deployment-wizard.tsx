"use client";

import { useState } from "react";

type SecretKey = "ADMIN_PASSWORD" | "ADMIN_SESSION_SECRET";

function randomHex(bytes: number) {
  const buffer = new Uint8Array(bytes);
  crypto.getRandomValues(buffer);
  return Array.from(buffer, (value) => value.toString(16).padStart(2, "0")).join("");
}

const steps = [
  {
    title: "Proje paketini indirin",
    body: "Aşağıdaki ZIP dosyası site kodunu ve otomatik veritabanı kurulumunu içerir. Gizli .env dosyası ve örnek müşteri kayıtları pakete dahil değildir.",
    link: null,
  },
  {
    title: "GitHub’da boş depo açıp dosyaları yükleyin",
    body: "GitHub’da New repository deyin, özel bir depo oluşturun. ZIP’i bilgisayarınızda açın; içindeki klasörleri ve dosyaları GitHub’ın upload files ekranına sürükleyip Commit changes ile kaydedin.",
    link: { label: "GitHub’da yeni depo aç", href: "https://github.com/new" },
  },
  {
    title: "Vercel’e GitHub deponuzu bağlayın",
    body: "Vercel’de Add New → Project deyin. GitHub hesabınızı bağlayıp açtığınız depoyu Import edin. Framework Next.js olarak seçili kalsın.",
    link: { label: "Vercel’de proje aç", href: "https://vercel.com/new" },
  },
  {
    title: "Neon veritabanını Vercel’e ekleyin",
    body: "Vercel projenizde Storage / Integrations bölümünden Neon Postgres ekleyin ve projeye bağlayın. DATABASE_URL otomatik eklenir. Plan ve bölge seçimini kendi hesabınızda onaylarsınız.",
    link: { label: "Neon bağlantı rehberi", href: "https://neon.com/docs/guides/vercel-managed-integration" },
  },
  {
    title: "Panel şifrelerini Vercel’e girin",
    body: "Aşağıdaki iki değeri üretip Vercel → Settings → Environment Variables bölümüne Production için ekleyin. Değerler yalnızca bu tarayıcı sekmesinde tutulur; kaydetmezseniz kaybolur.",
    link: { label: "Vercel ortam değişkenleri rehberi", href: "https://vercel.com/docs/environment-variables" },
  },
  {
    title: "Deploy deyin ve adresi kontrol edin",
    body: "Vercel size bir adres verir. İlk açılışta veritabanı tabloları otomatik hazırlanır. /api/health ok:true dönmeli, /panel şifre sormalı. Alan adınız varsa Settings → Domains bölümünden bağlayın.",
    link: { label: "Alan adı bağlama rehberi", href: "https://vercel.com/docs/domains/set-up-custom-domain" },
  },
];

export function DeploymentWizard() {
  const [done, setDone] = useState<boolean[]>(() => steps.map(() => false));
  const [secrets, setSecrets] = useState<Record<SecretKey, string>>({ ADMIN_PASSWORD: "", ADMIN_SESSION_SECRET: "" });
  const [copied, setCopied] = useState("");
  const [message, setMessage] = useState("");
  const [siteUrl, setSiteUrl] = useState("");

  function toggle(index: number) {
    setDone((previous) => previous.map((value, i) => (i === index ? !value : value)));
  }

  function generateSecrets() {
    if (typeof crypto === "undefined" || !crypto.getRandomValues) {
      setMessage("Bu tarayıcı güvenli değer üretimini desteklemiyor. Güncel bir tarayıcı kullanın.");
      return;
    }
    setSecrets({ ADMIN_PASSWORD: randomHex(16), ADMIN_SESSION_SECRET: randomHex(32) });
    setMessage("Değerler üretildi. İkisini de Vercel’e ekleyin; bu sekmeyi kapatmadan önce kopyalayın.");
  }

  async function copy(key: string, value: string) {
    if (!value) {
      setMessage("Önce güvenli değerleri üretin.");
      return;
    }
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
      setMessage(`${key} kopyalandı.`);
      window.setTimeout(() => setCopied((current) => (current === key ? "" : current)), 1800);
    } catch {
      setMessage("Otomatik kopyalanamadı. Kutudaki değeri seçip elle kopyalayın.");
    }
  }

  const normalizedUrl = siteUrl.trim() ? (siteUrl.trim().startsWith("http") ? siteUrl.trim().replace(/\/$/, "") : `https://${siteUrl.trim().replace(/\/$/, "")}`) : "";
  const completed = done.filter(Boolean).length;

  return (
    <div className="space-y-8">
      <div className="rounded-md border border-copper/30 bg-copper/8 p-5 text-sm leading-relaxed text-ink/75">
        <strong className="text-ink">Bu ekran yayın başlatmaz.</strong> Hesaplarınıza erişimim yok; hesap açma, plan seçme ve ödeme onayı sizde kalır. Şifre, token veya veritabanı adresi paylaşmayın.
      </div>

      <div className="flex items-center justify-between gap-4 rounded-md border border-ink/12 bg-paper p-5">
        <div><p className="eyebrow text-copper-dark">İlerleme</p><p className="mt-1 text-sm text-ink/65">{completed} / {steps.length} adım işaretlendi</p></div>
        <div className="h-2 w-32 overflow-hidden rounded-full bg-ink/10"><div className="h-full bg-copper transition-all" style={{ width: `${(completed / steps.length) * 100}%` }} /></div>
      </div>

      <ol className="space-y-4">
        {steps.map((step, index) => (
          <li key={step.title} className={`rounded-md border bg-paper p-6 ${done[index] ? "border-copper/50" : "border-ink/12"}`}>
            <div className="flex items-start gap-4">
              <button type="button" onClick={() => toggle(index)} aria-pressed={done[index]} aria-label={`${step.title} adımını ${done[index] ? "işareti kaldır" : "tamamlandı olarak işaretle"}`} className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full border text-xs font-bold ${done[index] ? "border-copper bg-copper text-ink" : "border-ink/20 text-ink/50"}`}>{done[index] ? "✓" : index + 1}</button>
              <div className="min-w-0 flex-1">
                <h2 className="display text-xl text-ink">{step.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-ink/65">{step.body}</p>
                {index === 0 && <a href="/downloads/pazera-yayin.zip" download className="btn btn-primary mt-4">Proje ZIP’ini indir <span aria-hidden="true">↓</span></a>}
                {step.link && <a href={step.link.href} target="_blank" rel="noreferrer noopener" className="mt-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.08em] text-copper-dark hover:text-ink">{step.link.label} <span aria-hidden="true">↗</span></a>}
                {index === 4 && (
                  <div className="mt-5 space-y-4 border-t border-ink/10 pt-5">
                    <button type="button" onClick={generateSecrets} className="btn btn-dark">Güvenli değerleri üret</button>
                    {(["ADMIN_PASSWORD", "ADMIN_SESSION_SECRET"] as SecretKey[]).map((key) => (
                      <div key={key}>
                        <label className="label" htmlFor={key}>{key}</label>
                        <div className="flex gap-2">
                          <input id={key} readOnly type="text" value={secrets[key]} placeholder="Henüz üretilmedi" className="field min-w-0 flex-1 font-mono text-xs" onFocus={(event) => event.currentTarget.select()} />
                          <button type="button" onClick={() => copy(key, secrets[key])} className="btn btn-ghost shrink-0 !px-4 !text-[0.625rem]">{copied === key ? "Kopyalandı" : "Kopyala"}</button>
                        </div>
                      </div>
                    ))}
                    <p className="text-xs leading-relaxed text-ink/50">Bu değerler sunucuya gönderilmez ve bu sayfada kalıcı saklanmaz. Vercel’e ekledikten sonra bu sekmeyi kapatabilirsiniz.</p>
                  </div>
                )}
              </div>
            </div>
          </li>
        ))}
      </ol>

      <div className="rounded-md border border-ink/12 bg-paper p-6">
        <h2 className="display text-xl text-ink">Yayın adresinizi kontrol edin</h2>
        <p className="mt-2 text-sm text-ink/60">Vercel’in verdiği adresi yazın. Bu alan sadece kontrol bağlantıları oluşturur.</p>
        <label className="label mt-4" htmlFor="published-url">Site adresi</label>
        <input id="published-url" value={siteUrl} onChange={(event) => setSiteUrl(event.target.value)} placeholder="https://proje-adi.vercel.app" className="field" />
        {normalizedUrl && <div className="mt-4 flex flex-wrap gap-3"><a href={`${normalizedUrl}/api/health`} target="_blank" rel="noreferrer noopener" className="btn btn-ghost !py-2.5 !text-[0.625rem]">Sağlık kontrolü ↗</a><a href={`${normalizedUrl}/panel`} target="_blank" rel="noreferrer noopener" className="btn btn-ghost !py-2.5 !text-[0.625rem]">Panel girişi ↗</a></div>}
      </div>

      {message && <p role="status" className="rounded-md border border-copper/30 bg-copper/8 px-4 py-3 text-sm text-ink/75">{message}</p>}
    </div>
  );
}
