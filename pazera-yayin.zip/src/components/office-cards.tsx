import { Icon } from "@/components/icon";
import { offices, whatsappUrl } from "@/content/site";

export function OfficeCards({ showNote = false }: { showNote?: boolean }) {
  return (
    <div>
      <div className="grid gap-6 md:grid-cols-3">
        {offices.map((office) => (
          <article key={office.id} className="card-line group overflow-hidden rounded-md">
            <div className="relative overflow-hidden">
              <img src={office.image} alt={office.imageAlt} className="h-52 w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" />
              <span className="absolute left-4 top-4 rounded border border-copper/50 bg-ink/75 px-2.5 py-1 text-[0.625rem] font-bold tracking-[0.16em] text-copper backdrop-blur-sm">{office.code}</span>
              <p className="absolute bottom-4 left-5 text-xs font-semibold uppercase tracking-[0.16em] text-paper/80">{office.region}</p>
            </div>
            <div className="p-6">
              <h3 className="display text-2xl text-ink">{office.country}</h3>
              <p className="mt-1 text-[0.625rem] font-bold uppercase tracking-[0.14em] text-copper-dark">{office.title}</p>
              <p className="mt-3 text-sm leading-relaxed text-ink/60">{office.description}</p>
              <a href={whatsappUrl(`Merhaba, ${office.country} ofisiniz ve bu pazardaki hizmetleriniz hakkında bilgi almak istiyorum.`)} target="_blank" rel="noreferrer noopener" className="mt-5 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.1em] text-ink hover:text-copper-dark">
                <Icon name="whatsapp" className="h-4 w-4" /> Ofis iletişimi <Icon name="arrow" className="h-3.5 w-3.5" />
              </a>
            </div>
          </article>
        ))}
      </div>
      {showNote && <p className="mt-6 text-center text-xs leading-relaxed text-ink/50">Ofis adresleri ve ziyaret planı için WhatsApp veya iletişim formu üzerinden ekibimizle görüşebilirsiniz.</p>}
    </div>
  );
}
