import Link from "next/link";
import { Logo } from "@/components/logo";
import { Icon } from "@/components/icon";
import { NewsletterForm } from "@/components/newsletter-form";
import { navigation, offices, services, site, whatsappUrl } from "@/content/site";

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ink text-paper">
      <div className="map-grid absolute inset-0 opacity-40" aria-hidden="true" />
      <div className="wrap relative">
        <div className="grid gap-10 border-b border-paper/15 py-14 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div>
            <p className="eyebrow text-copper">Pazera Dış Ticaret</p>
            <h2 className="display mt-4 max-w-[22ch] text-[clamp(2rem,4vw,3.2rem)] text-paper">İhracat yolculuğunuzda <em>yanınızdayız</em>.</h2>
            <p className="brand-tagline mt-3 text-2xl text-copper">{site.tagline}</p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row lg:justify-end">
            <a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp ile yazın</a>
            <Link href="/iletisim#talep-formu" className="btn btn-light">Teklif talep et</Link>
          </div>
        </div>

        <div className="grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-[1.25fr_0.8fr_0.75fr_1fr]">
          <div>
            <Logo full />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-paper/60">5 yıldır ihracatın içinde, 100 firma ile çalışıyoruz. Analizden operasyona, tasarımdan lojistiğe firmalara özel çözümler.</p>
            <div className="mt-5 max-w-sm"><NewsletterForm /></div>
          </div>
          <div>
            <p className="eyebrow text-copper">Hizmetler</p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper/70">
              {services.slice(0, 6).map((service) => <li key={service.slug}><Link href={`/hizmetler/${service.slug}`} className="hover:text-copper">{service.title}</Link></li>)}
              <li><Link href="/hizmetler" className="font-semibold text-copper">Tüm hizmetler →</Link></li>
            </ul>
          </div>
          <div>
            <p className="eyebrow text-copper">Sayfalar</p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper/70">
              {navigation.map((item) => <li key={item.href}><Link href={item.href} className="hover:text-copper">{item.label}</Link></li>)}
              <li><Link href="/hazirlik-analizi" className="hover:text-copper">Hazırlık Analizi</Link></li>
            </ul>
          </div>
          <div>
            <p className="eyebrow text-copper">Ofislerimiz & iletişim</p>
            <ul className="mt-4 space-y-2 text-sm text-paper/70">
              {offices.map((office) => <li key={office.id} className="flex items-center gap-2"><Icon name="pin" className="h-3.5 w-3.5 text-copper" />{office.country}</li>)}
            </ul>
            <div className="mt-5 space-y-2 border-t border-paper/15 pt-4 text-sm">
              <a href={`tel:${site.phoneInternational.replace(/\s/g, "")}`} className="block font-semibold text-paper hover:text-copper">{site.phone}</a>
              <a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="block text-paper/60 hover:text-copper">WhatsApp: {site.phoneInternational}</a>
              <p className="text-xs text-paper/45">{site.hours}</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-3 border-t border-paper/15 py-6 text-xs text-paper/45 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} {site.legalName}. Tüm hakları saklıdır.</p>
          <p>Gana · Suudi Arabistan · Suriye</p>
        </div>
      </div>
    </footer>
  );
}
