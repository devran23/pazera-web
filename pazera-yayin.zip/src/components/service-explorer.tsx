"use client";

import Link from "next/link";
import { useState } from "react";
import { Icon } from "@/components/icon";
import { services } from "@/content/site";

const groups = ["Tümü", ...Array.from(new Set(services.map((service) => service.group)))];

export function ServiceExplorer() {
  const [group, setGroup] = useState("Tümü");
  const [query, setQuery] = useState("");
  const normalized = query.trim().toLocaleLowerCase("tr-TR");
  const filtered = services.filter((service) => {
    const matchesGroup = group === "Tümü" || service.group === group;
    const matchesQuery = !normalized || `${service.title} ${service.short} ${service.keywords.join(" ")}`.toLocaleLowerCase("tr-TR").includes(normalized);
    return matchesGroup && matchesQuery;
  });

  return (
    <div>
      <div className="flex flex-col gap-5 border-b border-ink/12 pb-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-2">
          {groups.map((item) => (
            <button key={item} type="button" onClick={() => setGroup(item)} className={`rounded-md border px-3.5 py-2 text-[0.6875rem] font-bold uppercase tracking-[0.08em] transition-colors ${group === item ? "border-ink bg-ink text-paper" : "border-ink/15 text-ink/60 hover:border-copper"}`}>{item}</button>
          ))}
        </div>
        <label className="relative block w-full lg:max-w-xs">
          <span className="sr-only">Hizmet ara</span>
          <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Hizmet ara…" className="field !pl-10" />
        </label>
      </div>
      <p className="mt-5 text-xs uppercase tracking-[0.14em] text-ink/45">{filtered.length} hizmet listeleniyor</p>
      {filtered.length === 0 ? (
        <div className="mt-6 rounded-md border border-dashed border-ink/20 p-12 text-center">
          <p className="display text-2xl text-ink">Bu aramada hizmet bulunamadı.</p>
          <button type="button" onClick={() => { setQuery(""); setGroup("Tümü"); }} className="btn btn-ghost mt-5">Filtreleri temizle</button>
        </div>
      ) : (
        <div className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((service) => (
            <Link key={service.slug} href={`/hizmetler/${service.slug}`} className="card-line group flex flex-col rounded-md p-6">
              <div className="flex items-start justify-between gap-4">
                <span className="grid h-12 w-12 place-items-center rounded-md border border-copper/30 bg-copper/8 text-copper-dark"><Icon name={service.icon} className="h-6 w-6" /></span>
                <span className="text-[0.625rem] font-bold tracking-[0.16em] text-ink/35">{service.no}</span>
              </div>
              {service.recommended && <span className="mt-4 w-fit rounded-full bg-copper/12 px-2.5 py-1 text-[0.5625rem] font-bold uppercase tracking-[0.1em] text-copper-dark">Pazera önerisi</span>}
              <h3 className="display mt-4 text-[1.35rem] leading-snug text-ink group-hover:text-copper-dark">{service.title}</h3>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-ink/60">{service.short}</p>
              <div className="mt-6 flex items-center justify-between border-t border-ink/10 pt-4 text-[0.625rem] font-bold uppercase tracking-[0.1em] text-ink/45">
                {service.group}<Icon name="arrowUpRight" className="h-4 w-4 text-copper-dark transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
