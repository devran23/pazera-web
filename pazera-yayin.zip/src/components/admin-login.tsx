"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function AdminLogin({ configured }: { configured: boolean }) {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("loading");
    setError("");
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setState("error");
        setError(data.error ?? "Giriş yapılamadı.");
        return;
      }
      setPassword("");
      router.refresh();
    } catch {
      setState("error");
      setError("Bağlantı hatası. Tekrar deneyin.");
    }
  }

  return (
    <section className="bg-bone py-20 md:py-28">
      <div className="wrap">
        <div className="mx-auto max-w-md rounded-md border border-ink/12 bg-paper p-8">
          <p className="eyebrow text-copper-dark">Pazera · dahili alan</p>
          <h1 className="display mt-4 text-3xl text-ink">Talep paneli girişi</h1>
          <p className="mt-3 text-sm leading-relaxed text-ink/60">Müşteri taleplerini görüntülemek için yönetici şifresini girin.</p>
          {!configured ? (
            <div className="mt-6 rounded-md border border-copper/30 bg-copper/5 p-4 text-sm leading-relaxed text-ink/70">
              Panel erişimi henüz yapılandırılmadı. Hosting ortam değişkenlerine <strong>ADMIN_PASSWORD</strong> ve <strong>ADMIN_SESSION_SECRET</strong> ekleyip siteyi yeniden yayınlayın.
            </div>
          ) : (
            <form onSubmit={submit} className="mt-6 space-y-4">
              <div>
                <label className="label" htmlFor="admin-password">Yönetici şifresi</label>
                <input id="admin-password" type="password" required autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} className="field" />
              </div>
              {error && <p role="alert" className="text-sm text-copper-dark">{error}</p>}
              <button type="submit" disabled={state === "loading"} className="btn btn-primary w-full disabled:opacity-60">{state === "loading" ? "Kontrol ediliyor…" : "Panele giriş"}</button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
