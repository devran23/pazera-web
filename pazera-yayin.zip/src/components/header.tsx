"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo } from "@/components/logo";
import { Icon } from "@/components/icon";
import { navigation, offices, site, whatsappUrl } from "@/content/site";

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className={`sticky top-0 z-50 bg-ink text-paper transition-shadow duration-300 ${scrolled ? "shadow-[0_8px_30px_rgba(6,26,56,0.25)]" : ""}`}>
      <div className="hidden border-b border-paper/10 bg-ink-soft md:block">
        <div className="wrap flex h-9 items-center justify-between text-[0.6875rem] text-paper/60">
          <p className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-copper" />5 yıldır ihracatın içinde · 100 firma ile çalışıyoruz</p>
          <p className="tracking-[0.08em]">{offices.map((office) => office.country).join(" · ")}</p>
        </div>
      </div>

      <div className="wrap flex h-[82px] items-center justify-between gap-5">
        <Logo />
        <nav className="hidden items-center gap-5 lg:flex xl:gap-7" aria-label="Ana menü">
          {navigation.map((item) => {
            const base = item.href.split("#")[0];
            const isAnchor = item.href.includes("#");
            const active = !isAnchor && (pathname === base || (base !== "/" && pathname.startsWith(`${base}/`)));
            return (
              <Link key={item.href} href={item.href} className={`link-underline whitespace-nowrap text-[0.75rem] font-semibold transition-colors xl:text-[0.8125rem] ${active ? "text-copper" : "text-paper/75 hover:text-copper"}`}>
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="hidden items-center gap-4 sm:flex">
          <a href={`tel:${site.phoneInternational.replace(/\s/g, "")}`} className="hidden text-xs font-semibold text-paper/70 hover:text-copper 2xl:block">{site.phone}</a>
          <a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary !px-5 !py-3 !text-[0.6875rem]">
            <Icon name="whatsapp" className="h-4 w-4" /> WhatsApp
          </a>
        </div>
        <button type="button" onClick={() => setOpen((v) => !v)} className="grid h-11 w-11 place-items-center rounded-md border border-paper/20 text-paper lg:hidden" aria-expanded={open} aria-controls="mobile-nav" aria-label={open ? "Menüyü kapat" : "Menüyü aç"}>
          <span className="flex w-5 flex-col gap-[5px]">
            <span className={`h-[1.5px] w-full bg-current transition-transform duration-300 ${open ? "translate-y-[6.5px] rotate-45" : ""}`} />
            <span className={`h-[1.5px] w-full bg-current transition-opacity duration-200 ${open ? "opacity-0" : ""}`} />
            <span className={`h-[1.5px] w-full bg-current transition-transform duration-300 ${open ? "-translate-y-[6.5px] -rotate-45" : ""}`} />
          </span>
        </button>
      </div>

      {open && (
        <div id="mobile-nav" className="border-t border-paper/10 bg-ink lg:hidden">
          <nav className="wrap flex flex-col py-4" aria-label="Mobil menü">
            {navigation.map((item) => (
              <Link key={item.href} href={item.href} className="flex items-center justify-between border-b border-paper/10 py-4 text-base font-semibold text-paper/85">
                {item.label}<Icon name="arrow" className="h-4 w-4 text-copper" />
              </Link>
            ))}
            <a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary mt-5 w-full"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp ile yazın</a>
            <a href={`tel:${site.phoneInternational.replace(/\s/g, "")}`} className="mt-3 pb-2 text-center text-sm text-paper/60">{site.phone}</a>
          </nav>
        </div>
      )}
    </header>
  );
}
