"use client";

import { useState } from "react";
import { Icon } from "@/components/icon";
import { packages, services, site, whatsappUrl } from "@/content/site";

type FieldErrors = Record<string, string>;

const initial = {
  name: "",
  company: "",
  email: "",
  phone: "",
  country: "",
  service: "",
  packageName: "",
  volume: "",
  message: "",
  website: "",
};

export function LeadForm({ compact = false, initialService = "", initialPackage = "" }: { compact?: boolean; initialService?: string; initialPackage?: string }) {
  const [form, setForm] = useState({ ...initial, service: initialService, packageName: initialPackage });
  const [errors, setErrors] = useState<FieldErrors>({});
  const [state, setState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [feedback, setFeedback] = useState("");

  function update(key: keyof typeof initial, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("loading");
    setErrors({});
    setFeedback("");
    try {
      const res = await fetch("/api/leads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, source: compact ? "service-page" : "contact-page" }) });
      const data = (await res.json()) as { ok?: boolean; message?: string; error?: string; errors?: FieldErrors };
      if (!res.ok || !data.ok) {
        setErrors(data.errors ?? {});
        setState("error");
        setFeedback(data.error ?? "Form gönderilemedi.");
        return;
      }
      setState("success");
      setFeedback(data.message ?? "Talebiniz alındı.");
      setForm({ ...initial, service: initialService, packageName: initialPackage });
    } catch {
      setState("error");
      setFeedback("Bağlantı hatası. Lütfen tekrar deneyin.");
    }
  }

  if (state === "success") {
    return (
      <div className="rounded-md border border-copper/30 bg-copper/5 p-8">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-ink text-copper"><Icon name="check" className="h-5 w-5" /></div>
        <h3 className="display mt-6 text-3xl text-ink">Talebiniz bize ulaştı.</h3>
        <p className="mt-3 max-w-md text-sm leading-relaxed text-ink/70">{feedback}</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp ile devam edin</a>
          <button type="button" onClick={() => { setState("idle"); setFeedback(""); }} className="btn btn-ghost">Yeni talep</button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4" noValidate>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label" htmlFor="lead-name">Ad soyad *</label><input id="lead-name" className="field" value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Adınız Soyadınız" autoComplete="name" aria-invalid={Boolean(errors.name)} />{errors.name && <p className="mt-1 text-xs text-copper-dark">{errors.name}</p>}</div>
        <div><label className="label" htmlFor="lead-company">Firma</label><input id="lead-company" className="field" value={form.company} onChange={(e) => update("company", e.target.value)} placeholder="Firma adı" autoComplete="organization" /></div>
        <div><label className="label" htmlFor="lead-email">E-posta *</label><input id="lead-email" type="email" className="field" value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="ad@firma.com" autoComplete="email" aria-invalid={Boolean(errors.email)} />{errors.email && <p className="mt-1 text-xs text-copper-dark">{errors.email}</p>}</div>
        <div><label className="label" htmlFor="lead-phone">Telefon</label><input id="lead-phone" className="field" value={form.phone} onChange={(e) => update("phone", e.target.value)} placeholder="05xx xxx xx xx" autoComplete="tel" /></div>
        <div><label className="label" htmlFor="lead-country">Hedef ülke / pazar</label><input id="lead-country" className="field" value={form.country} onChange={(e) => update("country", e.target.value)} placeholder="Örn. Gana, Suudi Arabistan, Suriye" /></div>
        <div><label className="label" htmlFor="lead-volume">İhracat durumu</label><select id="lead-volume" className="field" value={form.volume} onChange={(e) => update("volume", e.target.value)}><option value="">Seçiniz</option><option value="Henüz başlamadık">Henüz başlamadık</option><option value="İhracata hazırlanıyoruz">İhracata hazırlanıyoruz</option><option value="Mevcut ihracatımızı büyütüyoruz">Mevcut ihracatımızı büyütüyoruz</option><option value="Yeni pazar/ürün değerlendiriyoruz">Yeni pazar/ürün değerlendiriyoruz</option></select></div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label" htmlFor="lead-package">İlgilendiğiniz paket</label><select id="lead-package" className="field" value={form.packageName} onChange={(e) => update("packageName", e.target.value)} aria-invalid={Boolean(errors.packageName)}><option value="">Paket seçmedim / tek hizmet</option>{packages.map((pkg) => <option key={pkg.id} value={pkg.id}>{pkg.name} · {pkg.subtitle}</option>)}</select>{errors.packageName && <p className="mt-1 text-xs text-copper-dark">{errors.packageName}</p>}</div>
        <div><label className="label" htmlFor="lead-service">İlgilendiğiniz hizmet</label><select id="lead-service" className="field" value={form.service} onChange={(e) => update("service", e.target.value)}><option value="">Henüz emin değilim</option>{services.map((service) => <option key={service.slug} value={service.title}>{service.title}</option>)}</select></div>
      </div>
      <p className="rounded-md border border-copper/20 bg-copper/5 px-4 py-3 text-xs leading-relaxed text-ink/60">Fiyatlar firmalara özel yapılan analizlere göre değişir. Paket seçimi, görüşme kapsamını belirlemek içindir; kesin ücret analiz sonrası teklif edilir.</p>
      <div><label className="label" htmlFor="lead-message">Nereden başlamak istiyorsunuz? *</label><textarea id="lead-message" className="field min-h-[120px] resize-y" value={form.message} onChange={(e) => update("message", e.target.value)} placeholder="Ürününüz, hedef pazarınız ve ihtiyaç duyduğunuz hizmetlerden kısaca bahsedin." aria-invalid={Boolean(errors.message)} />{errors.message && <p className="mt-1 text-xs text-copper-dark">{errors.message}</p>}</div>
      <div className="hidden" aria-hidden="true"><label htmlFor="lead-website">Website</label><input id="lead-website" tabIndex={-1} autoComplete="off" value={form.website} onChange={(e) => update("website", e.target.value)} /></div>
      {state === "error" && feedback && <p role="alert" className="rounded-md border border-copper/30 bg-copper/5 px-4 py-3 text-sm text-copper-dark">{feedback}</p>}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <button type="submit" disabled={state === "loading"} className="btn btn-primary disabled:opacity-60">{state === "loading" ? "Gönderiliyor…" : "Görüşme talep et"}<Icon name="arrow" className="h-4 w-4" /></button>
        <p className="max-w-[30ch] text-[0.6875rem] leading-relaxed text-ink/45">Bilgileriniz yalnızca talebinizi değerlendirmek için kullanılır. Dilerseniz {site.phone} üzerinden WhatsApp ile de ulaşabilirsiniz.</p>
      </div>
    </form>
  );
}
