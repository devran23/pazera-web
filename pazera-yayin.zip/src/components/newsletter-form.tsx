"use client";

import { useState } from "react";

export function NewsletterForm({ tone = "dark" }: { tone?: "dark" | "light" }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState("loading");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = (await res.json()) as { ok?: boolean; message?: string; error?: string };
      if (!res.ok || !data.ok) {
        setState("error");
        setMessage(data.error ?? "Kayıt tamamlanamadı, tekrar deneyin.");
        return;
      }
      setState("success");
      setMessage(data.message ?? "Listeye eklendiniz.");
      setEmail("");
    } catch {
      setState("error");
      setMessage("Bağlantı hatası. Lütfen tekrar deneyin.");
    }
  }

  const dark = tone === "dark";

  return (
    <div>
      <form onSubmit={onSubmit} className="flex flex-col gap-2 sm:flex-row">
        <label className="sr-only" htmlFor="newsletter-email">
          E-posta adresiniz
        </label>
        <input
          id="newsletter-email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="E-posta adresiniz"
          className={
            dark
              ? "min-w-0 flex-1 border border-paper/25 bg-paper/5 px-4 py-3 text-sm text-paper placeholder:text-paper/40 focus:border-copper focus:outline-none"
              : "min-w-0 flex-1 border border-ink/20 bg-paper px-4 py-3 text-sm text-ink placeholder:text-ink/40 focus:border-copper focus:outline-none"
          }
        />
        <button
          type="submit"
          disabled={state === "loading"}
          className={`btn shrink-0 !py-3 !text-[0.6875rem] ${
            dark ? "btn-primary" : "btn-dark"
          } disabled:opacity-60`}
        >
          {state === "loading" ? "Ekleniyor…" : "Bültene katıl"}
        </button>
      </form>
      {message && (
        <p
          role="status"
          className={`mt-2 text-xs ${
            state === "error" ? "text-red-300" : dark ? "text-sage" : "text-forest"
          }`}
        >
          {message}
        </p>
      )}
    </div>
  );
}
