import Link from "next/link";
import { Icon } from "@/components/icon";
import { packages, pricingNote } from "@/content/site";

export function PackageCards() {
  return (
    <div>
      <div className="grid gap-6 lg:grid-cols-3">
        {packages.map((pkg) => {
          const featured = Boolean(pkg.featured);
          return (
            <article key={pkg.id} className={`relative flex flex-col rounded-md border p-7 sm:p-8 ${featured ? "border-copper bg-ink text-paper shadow-[0_20px_50px_rgba(6,26,56,0.18)]" : "border-ink/12 bg-paper text-ink"}`}>
              {featured && <span className="absolute -top-3 left-7 rounded-full bg-copper px-3 py-1 text-[0.625rem] font-bold uppercase tracking-[0.12em] text-ink">Pazara giriş odağı</span>}
              <div className="flex items-center justify-between">
                <span className={`text-[0.625rem] font-bold tracking-[0.18em] ${featured ? "text-copper" : "text-ink/40"}`}>{pkg.no}</span>
                <Icon name={pkg.id === "baslangic" ? "compass" : pkg.id === "buyume" ? "chart" : "shield"} className={`h-6 w-6 ${featured ? "text-copper" : "text-ink/35"}`} />
              </div>
              <h3 className="display mt-5 text-3xl">{pkg.name}</h3>
              <p className={`mt-1 text-xs font-bold uppercase tracking-[0.14em] ${featured ? "text-copper" : "text-copper-dark"}`}>{pkg.subtitle}</p>
              <p className={`mt-4 text-sm leading-relaxed ${featured ? "text-paper/65" : "text-ink/60"}`}>{pkg.description}</p>
              <div className={`my-6 border-y py-5 ${featured ? "border-paper/15" : "border-ink/10"}`}>
                <p className="display text-[1.65rem]">Firmaya özel teklif</p>
                <p className={`mt-1 text-xs ${featured ? "text-paper/50" : "text-ink/45"}`}>Analiz sonrası fiyatlandırılır</p>
              </div>
              <ul className="space-y-3">
                {pkg.features.map((feature) => (
                  <li key={feature} className={`flex items-start gap-2.5 text-sm leading-relaxed ${featured ? "text-paper/75" : "text-ink/70"}`}>
                    <Icon name="check" className={`mt-0.5 h-4 w-4 shrink-0 ${featured ? "text-copper" : "text-copper-dark"}`} />{feature}
                  </li>
                ))}
              </ul>
              <p className={`mt-6 text-xs leading-relaxed ${featured ? "text-paper/45" : "text-ink/45"}`}>{pkg.idealFor}</p>
              <Link href={`/iletisim?paket=${pkg.id}#talep-formu`} className={`btn mt-7 w-full ${featured ? "btn-primary" : "btn-dark"}`}>Bu paket için görüşelim <Icon name="arrow" className="h-4 w-4" /></Link>
            </article>
          );
        })}
      </div>
      <p className="mx-auto mt-8 max-w-3xl text-center text-sm leading-relaxed text-ink/60">{pricingNote}</p>
    </div>
  );
}
