import type { Metadata } from "next";
import Link from "next/link";
import { DeploymentWizard } from "@/components/deployment-wizard";

export const metadata: Metadata = {
  title: "Yayın Hazırlık Merkezi",
  description: "Pazera projesini indirmek ve hesap sahibi için yayın adımlarını hazırlamak üzere dahili rehber.",
  robots: { index: false, follow: false },
};

export default function DeploymentPage() {
  return (
    <section className="bg-bone py-12 md:py-16">
      <div className="wrap max-w-4xl">
        <Link href="/" className="text-xs font-bold uppercase tracking-[0.12em] text-copper-dark hover:text-ink">← Siteye dön</Link>
        <p className="eyebrow mt-8 text-copper-dark">Pazera · dahili yayın rehberi</p>
        <h1 className="display mt-4 text-[clamp(2.2rem,5vw,3.6rem)] text-ink">Yayın hazırlık merkezi</h1>
        <p className="mt-4 max-w-2xl text-sm leading-relaxed text-ink/65">Komut yazmanız gerekmez. Proje paketi hazır; veritabanı tabloları ilk açılışta otomatik kurulur. Aşağıdaki adımlar kendi hesaplarınızda yapacağınız bağlantı ve onayları gösterir.</p>
        <div className="mt-10"><DeploymentWizard /></div>
      </div>
    </section>
  );
}
