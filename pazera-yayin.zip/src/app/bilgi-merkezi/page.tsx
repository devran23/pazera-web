import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/page-hero";
import { NewsletterForm } from "@/components/newsletter-form";
import { articles } from "@/content/site";

export const metadata: Metadata = {
  title: "Bilgi Merkezi",
  description:
    "Ürün analizi, pazar araştırması, lojistik, nakliye ve ihracatta dijital sunum üzerine Pazera'nın saha notları.",
};

type PageProps = { searchParams: Promise<{ kategori?: string }> };

export default async function InsightsPage({ searchParams }: PageProps) {
  const { kategori } = await searchParams;
  const categories = Array.from(new Set(articles.map((article) => article.category)));
  const active = kategori && categories.includes(kategori) ? kategori : null;
  const filtered = active ? articles.filter((article) => article.category === active) : articles;
  const [featured, ...rest] = filtered;

  return (
    <>
      <PageHero
        label="Bilgi Merkezi"
        title={
          <>
            İhracat kararları için <em>saha</em> notları.
          </>
        }
        breadcrumb={[{ label: "Bilgi Merkezi" }]}
      >
        <p className="text-sm leading-relaxed text-ink/60">
          Yayınlarımız danışmanlık masasından çıkar: güncel veriler, gerçek proje deneyimleri ve
          uygulanabilir kontrol listeleri. Reklam içermez.
        </p>
      </PageHero>

      <section className="bg-paper py-12 md:py-16">
        <div className="wrap">
          <div className="flex flex-wrap items-center gap-2 border-b border-ink/12 pb-6">
            <span className="mr-2 text-[0.625rem] uppercase tracking-[0.16em] text-ink/45">
              Kategori
            </span>
            <Link
              href="/bilgi-merkezi"
              className={`border px-3 py-1.5 text-[0.6875rem] font-semibold uppercase tracking-[0.1em] transition-colors ${
                active === null
                  ? "border-ink bg-ink text-paper"
                  : "border-ink/15 text-ink/60 hover:border-ink/40"
              }`}
            >
              Tümü
            </Link>
            {categories.map((category) => (
              <Link
                key={category}
                href={`/bilgi-merkezi?kategori=${encodeURIComponent(category)}`}
                className={`border px-3 py-1.5 text-[0.6875rem] font-semibold uppercase tracking-[0.1em] transition-colors ${
                  active === category
                    ? "border-ink bg-ink text-paper"
                    : "border-ink/15 text-ink/60 hover:border-ink/40"
                }`}
              >
                {category}
              </Link>
            ))}
          </div>

          {!featured && (
            <p className="py-16 text-center text-sm text-ink/50">
              Bu kategoride henüz yazı yok.{" "}
              <Link href="/bilgi-merkezi" className="text-copper underline">
                Tüm yazılara dön
              </Link>
            </p>
          )}

          {featured && (
            <Link
              href={`/bilgi-merkezi/${featured.slug}`}
              className="group mt-8 grid gap-8 border-b border-ink/12 pb-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center"
            >
              <div className="overflow-hidden">
                <img
                  src={featured.image}
                  alt={featured.title}
                  className="h-[280px] w-full object-cover transition-transform duration-700 group-hover:scale-[1.02] sm:h-[360px]"
                  loading="eager"
                />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-3 text-[0.625rem] uppercase tracking-[0.16em]">
                  <span className="bg-copper px-2.5 py-1 text-paper">Öne çıkan</span>
                  <span className="text-copper">{featured.category}</span>
                  <span className="text-ink/40">{featured.date}</span>
                </div>
                <h2 className="display mt-4 text-[clamp(1.9rem,3.3vw,2.7rem)] leading-tight text-ink">
                  {featured.title}
                </h2>
                <p className="mt-4 max-w-xl text-sm leading-relaxed text-ink/60">
                  {featured.excerpt}
                </p>
                <div className="mt-6 flex items-center gap-4 text-xs text-ink/50">
                  <span>{featured.author}</span>
                  <span className="h-px w-5 bg-ink/25" />
                  <span>{featured.readTime} okuma</span>
                </div>
                <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-ink group-hover:text-copper">
                  Yazıyı oku →
                </span>
              </div>
            </Link>
          )}

          {rest.length > 0 && (
            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {rest.map((article) => (
                <Link key={article.slug} href={`/bilgi-merkezi/${article.slug}`} className="group">
                  <div className="overflow-hidden">
                    <img
                      src={article.image}
                      alt={article.title}
                      className="h-[210px] w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                      loading="lazy"
                    />
                  </div>
                  <div className="mt-4 flex items-center gap-3 text-[0.625rem] uppercase tracking-[0.16em]">
                    <span className="text-copper">{article.category}</span>
                    <span className="h-px w-4 bg-ink/25" />
                    <span className="text-ink/40">{article.readTime}</span>
                  </div>
                  <h3 className="display mt-3 text-[1.45rem] leading-snug text-ink group-hover:text-copper">
                    {article.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink/55">
                    {article.excerpt}
                  </p>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="border-t border-ink/10 bg-bone py-14">
        <div className="wrap grid gap-8 lg:grid-cols-[1fr_1fr] lg:items-center">
          <div>
            <p className="eyebrow text-copper">Aylık bülten</p>
            <h2 className="display mt-3 text-[clamp(1.8rem,3vw,2.4rem)] text-ink">
              Yeni yazılar e-postanıza gelsin.
            </h2>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-ink/60">
              Ayda bir kez: bir pazar analizi, bir operasyon kontrol listesi ve tasarım/sunum
              önerileri.
            </p>
          </div>
          <div className="border border-ink/12 bg-paper p-6">
            <NewsletterForm tone="light" />
            <p className="mt-3 text-[0.6875rem] text-ink/45">
              Yeni yazılardan haberdar olmak için kaydolun. Tek tıkla çıkabilirsiniz.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
