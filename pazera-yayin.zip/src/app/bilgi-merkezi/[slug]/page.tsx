import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { NewsletterForm } from "@/components/newsletter-form";
import { articles } from "@/content/site";

type PageProps = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return articles.map((article) => ({ slug: article.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const article = articles.find((item) => item.slug === slug);
  if (!article) return { title: "Yazı bulunamadı" };

  return {
    title: article.title,
    description: article.excerpt,
    openGraph: {
      title: article.title,
      description: article.excerpt,
      type: "article",
      images: [{ url: article.image }],
    },
  };
}

export default async function ArticlePage({ params }: PageProps) {
  const { slug } = await params;
  const article = articles.find((item) => item.slug === slug);

  if (!article) notFound();

  const related = articles.filter((item) => item.slug !== article.slug).slice(0, 2);

  return (
    <>
      <article>
        <header className="border-b border-ink/10 bg-bone">
          <div className="wrap py-12 md:py-16">
            <nav aria-label="Sayfa yolu" className="flex flex-wrap items-center gap-2 text-xs text-ink/45">
              <Link href="/" className="hover:text-copper">
                Ana sayfa
              </Link>
              <span className="text-ink/25">/</span>
              <Link href="/bilgi-merkezi" className="hover:text-copper">
                Bilgi Merkezi
              </Link>
              <span className="text-ink/25">/</span>
              <span className="text-ink/70">{article.category}</span>
            </nav>

            <div className="mt-8 max-w-3xl">
              <div className="flex flex-wrap items-center gap-3 text-[0.625rem] uppercase tracking-[0.16em]">
                <span className="bg-copper px-2.5 py-1 text-paper">{article.category}</span>
                <span className="text-ink/45">{article.date}</span>
                <span className="h-px w-5 bg-ink/25" />
                <span className="text-ink/45">{article.readTime} okuma</span>
              </div>
              <h1 className="display mt-6 text-[clamp(2.2rem,4.6vw,3.7rem)] text-ink">
                {article.title}
              </h1>
              <p className="mt-5 max-w-2xl text-[1.0625rem] leading-relaxed text-ink/65">
                {article.excerpt}
              </p>
              <div className="mt-7 flex items-center gap-3 border-t border-ink/12 pt-5">
                <span className="display grid h-10 w-10 place-items-center rounded-full border border-copper/30 text-sm text-copper">
                  {article.author
                    .split(" ")
                    .map((part) => part[0])
                    .join("")}
                </span>
                <div>
                  <p className="text-sm font-semibold text-ink">{article.author}</p>
                  <p className="text-[0.6875rem] text-ink/50">Pazera danışmanlık ekibi</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="bg-paper">
          <div className="wrap grid gap-12 py-12 md:py-16 lg:grid-cols-[1fr_320px] lg:gap-16">
            <div>
              <img
                src={article.image}
                alt={article.title}
                className="h-[280px] w-full object-cover sm:h-[400px]"
                loading="eager"
              />

              <div className="mt-10 max-w-2xl">
                <p className="display text-[1.35rem] leading-relaxed text-ink/80">
                  {article.intro}
                </p>
                <div className="mt-8 space-y-8">
                  {article.sections.map((section) => (
                    <section key={section.heading}>
                      <h2 className="display text-[1.6rem] leading-snug text-ink">
                        {section.heading}
                      </h2>
                      <div className="mt-3 space-y-4">
                        {section.paragraphs.map((paragraph) => (
                          <p
                            key={paragraph.slice(0, 32)}
                            className="text-[0.9375rem] leading-[1.85] text-ink/70"
                          >
                            {paragraph}
                          </p>
                        ))}
                      </div>
                      {section.bullets && (
                        <ul className="mt-4 space-y-2.5 border-l-2 border-copper/40 pl-5">
                          {section.bullets.map((bullet) => (
                            <li key={bullet} className="text-sm leading-relaxed text-ink/70">
                              {bullet}
                            </li>
                          ))}
                        </ul>
                      )}
                    </section>
                  ))}
                </div>

                <div className="mt-12 border-t border-ink/12 pt-6">
                  <p className="text-xs leading-relaxed text-ink/50">
                    Bu yazı genel bilgilendirme amaçlıdır. Firmanıza özel uygulama için Pazera
                    ekibiyle görüşmenizi öneririz.
                  </p>
                  <Link href="/iletisim" className="btn btn-dark mt-5">
                    Uzman görüşü alın
                  </Link>
                </div>
              </div>
            </div>

            <aside className="space-y-5 lg:sticky lg:top-28 lg:self-start">
              <div className="border border-ink/12 bg-bone/60 p-6">
                <p className="eyebrow text-copper">Aylık bülten</p>
                <p className="mt-2 text-sm leading-relaxed text-ink/65">
                  Yeni pazar analizleri ve operasyon listeleri e-postanıza gelsin.
                </p>
                <div className="mt-4">
                  <NewsletterForm tone="light" />
                </div>
              </div>

              <div className="border border-ink/12 p-6">
                <p className="eyebrow text-copper">İlgili yazılar</p>
                <div className="mt-3 divide-y divide-ink/10">
                  {related.map((item) => (
                    <Link key={item.slug} href={`/bilgi-merkezi/${item.slug}`} className="group block py-4">
                      <p className="text-[0.625rem] uppercase tracking-[0.14em] text-ink/40">
                        {item.category}
                      </p>
                      <p className="mt-1 text-sm font-semibold leading-snug text-ink group-hover:text-copper">
                        {item.title}
                      </p>
                    </Link>
                  ))}
                </div>
              </div>

              <div className="bg-ink p-6 text-paper">
                <p className="eyebrow text-copper">Hazırlık analizi</p>
                <p className="mt-2 text-sm leading-relaxed text-paper/70">
                  İhracata ne kadar hazır olduğunuzu 2 dakikada ölçün.
                </p>
                <Link href="/hazirlik-analizi" className="btn btn-light mt-4 w-full">
                  Analizi başlat
                </Link>
              </div>
            </aside>
          </div>
        </div>
      </article>
    </>
  );
}
