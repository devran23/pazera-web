import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/page-hero";
import { Icon } from "@/components/icon";
import { ServiceExplorer } from "@/components/service-explorer";
import { PackageCards } from "@/components/package-cards";
import { faqs, process, whatsappUrl } from "@/content/site";

export const metadata: Metadata = {
  title: "Hizmetler ve Paketler",
  description: "Ürün analizi, pazar araştırması, rakip ve fiyat analizi, gümrük, lojistik, nakliye müşavirliği, web sitesi ve katalog tasarımı. Başlangıç, Büyüme ve Kurumsal paketler.",
};

export default function ServicesPage() {
  return (
    <>
      <PageHero label="Hizmetler" title={<>Analizden operasyona, <em>12 hizmet</em> tek çatı altında.</>} breadcrumb={[{ label: "Hizmetler" }]}>
        <div><p className="text-sm leading-relaxed text-ink/60">Sizin belirlediğiniz 9 temel hizmete, ihtiyacı tamamlayan 3 Pazera önerisi ekledik. Tek hizmet de alabilir, paket kapsamında da ilerleyebilirsiniz.</p><div className="mt-5 flex flex-wrap gap-6 border-t border-ink/12 pt-4 text-xs text-ink/55"><span><strong className="display mr-1 text-xl text-copper-dark">12</strong> hizmet</span><span><strong className="display mr-1 text-xl text-copper-dark">3</strong> paket</span><span><strong className="display mr-1 text-xl text-copper-dark">3</strong> ofis</span></div></div>
      </PageHero>

      <section className="bg-paper py-14 md:py-20"><div className="wrap"><ServiceExplorer /></div></section>

      <section id="paketler" className="scroll-mt-32 border-y border-ink/10 bg-bone py-20 md:py-24">
        <div className="wrap"><div className="mx-auto max-w-2xl text-center"><p className="eyebrow text-copper-dark">Hizmet paketleri</p><h2 className="display mt-4 text-[clamp(2rem,4vw,3.2rem)] text-ink">Üç hizmet paketi, <em>firmaya özel</em> fiyat.</h2><p className="mt-4 text-sm leading-relaxed text-ink/60">Fiyatlar firmalara özel yapılan analizlere göre değişir. Paket içerikleri ihtiyaçlarınıza göre şekillendirilir.</p></div><div className="mt-12"><PackageCards /></div></div>
      </section>

      <section className="bg-paper py-16 md:py-20"><div className="wrap"><div className="max-w-2xl"><p className="eyebrow text-copper-dark">Süreç</p><h2 className="display mt-4 text-[clamp(1.9rem,3.4vw,2.7rem)] text-ink">Tekliften önce <em>analiz</em> yaparız.</h2></div><div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">{process.map((step) => <div key={step.no} className="border-t border-ink/12 pt-5"><span className="display text-3xl text-copper-dark">{step.no}</span><h3 className="mt-3 text-base font-semibold text-ink">{step.title}</h3><p className="mt-2 text-sm leading-relaxed text-ink/60">{step.detail}</p></div>)}</div></div></section>

      <section className="border-t border-ink/10 bg-bone py-16"><div className="wrap grid gap-10 lg:grid-cols-[0.8fr_1.2fr]"><div><p className="eyebrow text-copper-dark">Sık sorular</p><h2 className="display mt-4 text-[clamp(1.9rem,3.4vw,2.6rem)] text-ink">Hizmet ve fiyatlandırma hakkında.</h2><a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary mt-6"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp ile sorun</a></div><div className="border-t border-ink/12">{faqs.slice(2).map((faq) => <details key={faq.q} className="group border-b border-ink/12 py-5"><summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-[0.9375rem] font-semibold text-ink">{faq.q}<span className="text-copper-dark transition-transform group-open:rotate-45">+</span></summary><p className="mt-3 text-sm leading-relaxed text-ink/60">{faq.a}</p></details>)}<Link href="/iletisim#talep-formu" className="btn btn-dark mt-7">Firmama özel teklif isteyin</Link></div></div></section>
    </>
  );
}
