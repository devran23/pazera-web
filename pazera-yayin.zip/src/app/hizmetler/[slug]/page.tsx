import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/page-hero";
import { LeadForm } from "@/components/lead-form";
import { Icon } from "@/components/icon";
import { services, whatsappUrl } from "@/content/site";

type PageProps = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return services.map((service) => ({ slug: service.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const service = services.find((item) => item.slug === slug);
  if (!service) return { title: "Hizmet bulunamadı" };
  return { title: service.title, description: service.short, keywords: service.keywords, openGraph: { title: `${service.title} · Pazera`, description: service.short, images: [{ url: service.image }] } };
}

export default async function ServiceDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const service = services.find((item) => item.slug === slug);
  if (!service) notFound();
  const related = services.filter((item) => item.slug !== service.slug && item.group === service.group).slice(0, 3);
  const fallbackRelated = services.filter((item) => item.slug !== service.slug).slice(0, 3);
  const suggestions = related.length > 0 ? related : fallbackRelated;

  return (
    <>
      <PageHero label={`Hizmet ${service.no} · ${service.group}`} title={service.title} breadcrumb={[{ label: "Hizmetler", href: "/hizmetler" }, { label: service.title }]}>
        <div>{service.recommended && <span className="mb-3 inline-block rounded-full bg-copper/12 px-3 py-1 text-[0.625rem] font-bold uppercase tracking-[0.1em] text-copper-dark">Pazera’nın önerdiği tamamlayıcı hizmet</span>}<p className="text-[1.0625rem] leading-relaxed text-ink/70">{service.hero}</p></div>
      </PageHero>

      <section className="bg-paper py-16 md:py-20">
        <div className="wrap grid gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
          <div>
            <div className="relative overflow-hidden rounded-md"><img src={service.image} alt={service.title} className="h-[300px] w-full object-cover sm:h-[380px]" loading="eager" /><span className="absolute left-5 top-5 grid h-14 w-14 place-items-center rounded-md border border-copper/40 bg-ink/80 text-copper backdrop-blur-sm"><Icon name={service.icon} className="h-7 w-7" /></span></div>
            <div className="mt-9 space-y-5">{service.body.map((paragraph) => <p key={paragraph.slice(0, 32)} className="text-[0.9375rem] leading-[1.8] text-ink/75">{paragraph}</p>)}</div>
            <div className="mt-10"><p className="eyebrow text-copper-dark">Neler sunuyoruz?</p><ul className="mt-5 grid gap-x-8 gap-y-4 sm:grid-cols-2">{service.deliverables.map((item, index) => <li key={item} className="flex items-start gap-3 border-t border-ink/12 pt-4"><span className="text-[0.625rem] font-bold tracking-[0.1em] text-copper-dark">{String(index + 1).padStart(2, "0")}</span><span className="text-sm leading-relaxed text-ink/70">{item}</span></li>)}</ul></div>
            <div className="mt-10 grid gap-4 sm:grid-cols-3">{service.outcomes.map((outcome) => <div key={outcome.label} className="rounded-md border border-ink/12 bg-bone/60 p-5"><p className="display text-[1.25rem] leading-tight text-ink">{outcome.value}</p><p className="mt-2 text-[0.625rem] uppercase tracking-[0.12em] text-ink/50">{outcome.label}</p></div>)}</div>
          </div>
          <aside className="space-y-5 lg:sticky lg:top-32 lg:self-start">
            <div className="rounded-md border border-ink/12 bg-bone/70 p-6"><p className="eyebrow text-copper-dark">Kimler için?</p><ul className="mt-4 space-y-3">{service.idealFor.map((item) => <li key={item} className="flex items-start gap-2.5 text-sm leading-relaxed text-ink/70"><Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-copper-dark" />{item}</li>)}</ul><div className="mt-5 border-t border-ink/12 pt-4"><p className="text-[0.625rem] uppercase tracking-[0.14em] text-ink/45">Planlama</p><p className="mt-1 text-sm font-semibold text-ink">{service.timeline}</p></div></div>
            <div className="rounded-md bg-ink p-6 text-paper"><p className="eyebrow text-copper">Firmaya özel teklif</p><p className="display mt-3 text-2xl leading-snug">Bu hizmetin kapsamını firmanızla birlikte netleştirelim.</p><p className="mt-3 text-xs leading-relaxed text-paper/60">Fiyat, firmaya özel analiz sonrası belirlenir. Tek hizmet veya paket kapsamında görüşebiliriz.</p><a href={whatsappUrl(`Merhaba, ${service.title} hizmetiniz hakkında firmama özel bilgi ve teklif almak istiyorum.`)} target="_blank" rel="noreferrer noopener" className="btn btn-primary mt-5 w-full"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp ile sorun</a><Link href={`/iletisim?hizmet=${service.slug}#talep-formu`} className="btn btn-light mt-3 w-full">Form ile teklif isteyin</Link></div>
          </aside>
        </div>
      </section>

      <section className="border-t border-ink/10 bg-bone py-16"><div className="wrap grid gap-10 lg:grid-cols-[0.9fr_1.1fr]"><div><p className="eyebrow text-copper-dark">İlk adım</p><h2 className="display mt-4 text-[clamp(1.9rem,3.4vw,2.7rem)] text-ink">İhtiyacınızı anlatın, <em>kapsamı birlikte</em> belirleyelim.</h2><p className="mt-4 max-w-md text-sm leading-relaxed text-ink/60">Formu doldurun; talebiniz ilgili ekip arkadaşımıza yönlendirilsin.</p></div><div className="rounded-md border border-ink/12 bg-paper p-6 sm:p-8"><LeadForm compact initialService={service.title} /></div></div></section>

      <section className="bg-paper py-14"><div className="wrap"><div className="flex items-end justify-between gap-6"><h2 className="display text-[clamp(1.6rem,3vw,2.2rem)] text-ink">İlgili hizmetler</h2><Link href="/hizmetler" className="text-sm font-semibold text-ink hover:text-copper-dark">Tümü →</Link></div><div className="mt-7 grid gap-5 md:grid-cols-3">{suggestions.map((item) => <Link key={item.slug} href={`/hizmetler/${item.slug}`} className="card-line rounded-md p-6"><Icon name={item.icon} className="h-6 w-6 text-copper-dark" /><h3 className="display mt-4 text-xl text-ink">{item.title}</h3><p className="mt-2 text-sm leading-relaxed text-ink/55">{item.short}</p></Link>)}</div></div></section>
    </>
  );
}
