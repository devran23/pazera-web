import Link from "next/link";
import { Icon } from "@/components/icon";
import { PackageCards } from "@/components/package-cards";
import { OfficeCards } from "@/components/office-cards";
import { articles, offices, process, services, site, stats, whatsappUrl } from "@/content/site";

export default function HomePage() {
  const coreServices = services.filter((service) => !service.recommended);
  const extraServices = services.filter((service) => service.recommended);

  return (
    <>
      <section className="relative overflow-hidden bg-ink text-paper">
        <div className="dot-grid absolute inset-0 opacity-30" aria-hidden="true" />
        <div className="gold-glow absolute -right-40 -top-40 h-[620px] w-[620px]" aria-hidden="true" />
        <div className="wrap relative grid items-center gap-12 py-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16 lg:py-20">
          <div>
            <p className="eyebrow rise flex items-center gap-3 text-copper"><span className="h-px w-8 bg-copper" /> Pazera Dış Ticaret</p>
            <h1 className="display rise rise-1 mt-6 text-[clamp(2.8rem,6vw,5.2rem)] text-paper">Dünyaya açılan <em>ticaret kapınız.</em></h1>
            <p className="rise rise-2 mt-6 max-w-xl text-[1.0625rem] leading-relaxed text-paper/70">5 yıldır ihracatın içindeyiz. 100 firma ile çalışıyor; ürün analizinden gümrük ve lojistiğe, web sitesi ve katalog tasarımına kadar firmanıza özel çözümler sunuyoruz.</p>
            <div className="rise rise-3 mt-8 flex flex-wrap gap-3">
              <a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp ile görüşelim</a>
              <Link href="/hizmetler" className="btn btn-light">Hizmetleri keşfedin <Icon name="arrow" className="h-4 w-4" /></Link>
            </div>
            <div className="rise rise-4 mt-10 flex flex-wrap gap-x-8 gap-y-3 border-t border-paper/15 pt-6 text-xs text-paper/55">
              <span><strong className="mr-1.5 text-base text-copper">5</strong> yıl deneyim</span>
              <span><strong className="mr-1.5 text-base text-copper">100</strong> firma</span>
              <span><strong className="mr-1.5 text-base text-copper">3</strong> ofis</span>
            </div>
          </div>
          <div className="rise rise-2 relative">
            <div className="relative overflow-hidden rounded-md border border-copper/30">
              <img src="https://images.pexels.com/photos/6595780/pexels-photo-6595780.jpeg?auto=compress&cs=tinysrgb&w=1400" alt="Limanında yük operasyonu yürütülen konteyner gemisi" className="h-[360px] w-full object-cover sm:h-[440px] lg:h-[520px]" loading="eager" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-ink/10" />
              <img src={site.mark} alt="" className="absolute right-5 top-5 h-20 w-20 opacity-90 sm:h-24 sm:w-24" />
              <div className="absolute inset-x-5 bottom-5 rounded-md border border-paper/15 bg-ink/80 p-5 backdrop-blur-sm">
                <p className="eyebrow text-copper">Üç ofis, tek çalışma disiplini</p>
                <div className="mt-3 flex flex-wrap gap-2">{offices.map((office) => <span key={office.id} className="rounded border border-paper/20 px-3 py-1.5 text-xs text-paper/80">{office.country}</span>)}</div>
              </div>
            </div>
            <div className="absolute -left-5 top-10 hidden rounded-md border border-copper/30 bg-paper p-5 text-ink shadow-xl xl:block">
              <p className="display text-4xl text-copper-dark">100</p>
              <p className="mt-1 max-w-[12ch] text-xs leading-relaxed text-ink/60">firma ile çalışıyoruz</p>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-ink/10 bg-paper">
        <dl className="wrap grid grid-cols-2 gap-y-8 py-9 lg:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.label} className="lg:border-l lg:border-ink/10 lg:pl-8 lg:first:border-l-0 lg:first:pl-0">
              <dd className="display text-[2.5rem] leading-none text-ink">{stat.value}<span className="ml-1.5 text-base font-normal tracking-normal text-copper-dark">{stat.suffix}</span></dd>
              <dt className="mt-2 text-xs leading-relaxed text-ink/50">{stat.label}</dt>
            </div>
          ))}
        </dl>
      </section>

      <section className="bg-bone py-20 md:py-24">
        <div className="wrap">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div className="max-w-2xl"><p className="eyebrow text-copper-dark">Hizmetlerimiz</p><h2 className="display mt-4 text-[clamp(2rem,4vw,3.2rem)] text-ink">İhracatın her adımı için <em>yanınızdayız</em>.</h2></div>
            <Link href="/hizmetler" className="btn btn-ghost shrink-0">Tüm hizmetler <Icon name="arrow" className="h-4 w-4" /></Link>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {coreServices.map((service) => (
              <Link key={service.slug} href={`/hizmetler/${service.slug}`} className="card-line group flex flex-col rounded-md p-6">
                <div className="flex items-center justify-between"><span className="grid h-12 w-12 place-items-center rounded-md border border-copper/30 bg-copper/8 text-copper-dark"><Icon name={service.icon} className="h-6 w-6" /></span><span className="text-[0.625rem] font-bold tracking-[0.16em] text-ink/35">{service.no}</span></div>
                <h3 className="display mt-5 text-[1.35rem] text-ink group-hover:text-copper-dark">{service.title}</h3>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-ink/60">{service.short}</p>
                <span className="mt-5 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.1em] text-ink/50 group-hover:text-copper-dark">Detayları inceleyin <Icon name="arrow" className="h-3.5 w-3.5" /></span>
              </Link>
            ))}
          </div>
          <div className="mt-8 grid gap-8 rounded-md bg-ink p-8 text-paper lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
            <div><p className="eyebrow text-copper">Pazera önerisi</p><h3 className="display mt-3 text-2xl">İhtiyacınızı tamamlayan 3 hizmet daha.</h3><p className="mt-3 text-sm leading-relaxed text-paper/60">Listelerinize ek olarak alıcı geliştirme, süreç danışmanlığı ve marka/ambalaj başlıklarını da kapsama alabiliyoruz.</p></div>
            <div className="grid gap-3 sm:grid-cols-3">{extraServices.map((service) => <Link key={service.slug} href={`/hizmetler/${service.slug}`} className="rounded-md border border-paper/15 p-4 transition-colors hover:border-copper/50"><Icon name={service.icon} className="h-5 w-5 text-copper" /><p className="mt-3 text-sm font-semibold leading-snug">{service.title}</p></Link>)}</div>
          </div>
        </div>
      </section>

      <section className="border-y border-ink/10 bg-paper py-20 md:py-24">
        <div className="wrap">
          <div className="mx-auto max-w-2xl text-center"><p className="eyebrow text-copper-dark">Hizmet paketleri</p><h2 className="display mt-4 text-[clamp(2rem,4vw,3.2rem)] text-ink">Üç paket, <em>firmaya özel</em> fiyat.</h2><p className="mt-4 text-sm leading-relaxed text-ink/60">Başlangıç, Büyüme ve Kurumsal paketlerimizin kapsamı örnektir. Ücret, firmanıza özel analiz sonrasında belirlenir.</p></div>
          <div className="mt-12"><PackageCards /></div>
        </div>
      </section>

      <section className="bg-bone py-20 md:py-24">
        <div className="wrap">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><div className="max-w-2xl"><p className="eyebrow text-copper-dark">Ofislerimiz</p><h2 className="display mt-4 text-[clamp(2rem,4vw,3.2rem)] text-ink">Üç ülkede <em>saha iletişimi</em>.</h2></div><Link href="/iletisim#ofisler" className="btn btn-ghost shrink-0">Ofislerimiz <Icon name="arrow" className="h-4 w-4" /></Link></div>
          <div className="mt-10"><OfficeCards /></div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-ink py-20 text-paper">
        <div className="map-grid absolute inset-0 opacity-40" aria-hidden="true" />
        <div className="wrap relative grid items-center gap-12 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="overflow-hidden rounded-md border border-copper/25"><img src={site.logo} alt="Pazera Dış Ticaret logosu ve sloganı" className="h-auto w-full" loading="lazy" /></div>
          <div><p className="eyebrow text-copper">Hakkımızda</p><h2 className="display mt-4 text-[clamp(2rem,4vw,3.2rem)]">5 yıldır ihracatın içinde, <em>100 firma</em> ile yan yana.</h2><p className="mt-5 max-w-xl text-sm leading-relaxed text-paper/65">Pazera; firmaların ürün, pazar, operasyon ve sunum ihtiyaçlarını birlikte ele alan dış ticaret firmasıdır. Gana, Suudi Arabistan ve Suriye ofislerimizle hedef bölgelerdeki iletişimi destekliyoruz.</p><p className="mt-6 border-l-2 border-copper pl-4 text-sm"><strong className="block text-paper">Devran Taşpınar</strong><span className="text-paper/55">Şirket Kurucusu</span></p><Link href="/hakkimizda" className="btn btn-light mt-7">Ekibi ve yaklaşımımızı tanıyın <Icon name="arrow" className="h-4 w-4" /></Link></div>
        </div>
      </section>

      <section className="bg-paper py-20">
        <div className="wrap"><div className="max-w-2xl"><p className="eyebrow text-copper-dark">Nasıl çalışıyoruz?</p><h2 className="display mt-4 text-[clamp(2rem,4vw,3rem)] text-ink">Önce ihtiyaç, sonra <em>özel teklif</em>.</h2></div><div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">{process.map((step) => <div key={step.no} className="border-t border-ink/12 pt-6"><span className="display text-3xl text-copper-dark">{step.no}</span><h3 className="mt-4 text-base font-semibold text-ink">{step.title}</h3><p className="mt-2 text-sm leading-relaxed text-ink/60">{step.detail}</p><p className="mt-4 text-[0.625rem] uppercase tracking-[0.14em] text-ink/40">{step.duration}</p></div>)}</div></div>
      </section>

      <section className="border-t border-ink/10 bg-bone py-20">
        <div className="wrap"><div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="eyebrow text-copper-dark">Bilgi Merkezi</p><h2 className="display mt-4 text-[clamp(2rem,4vw,3rem)] text-ink">Karar vermeden önce <em>okuyun</em>.</h2></div><Link href="/bilgi-merkezi" className="btn btn-ghost shrink-0">Tüm yazılar</Link></div><div className="mt-10 grid gap-6 md:grid-cols-3">{articles.slice(0, 3).map((article) => <Link key={article.slug} href={`/bilgi-merkezi/${article.slug}`} className="group"><div className="overflow-hidden rounded-md"><img src={article.image} alt={article.title} className="h-52 w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]" loading="lazy" /></div><p className="mt-4 text-[0.625rem] font-bold uppercase tracking-[0.14em] text-copper-dark">{article.category} · {article.readTime}</p><h3 className="display mt-2 text-xl leading-snug text-ink group-hover:text-copper-dark">{article.title}</h3></Link>)}</div></div>
      </section>

      <section className="bg-ink py-16 text-paper">
        <div className="wrap grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center"><div><p className="eyebrow text-copper">İletişim</p><h2 className="display mt-3 text-[clamp(1.9rem,3.6vw,2.8rem)]">Firmanız için doğru kapsamı birlikte belirleyelim.</h2><p className="mt-3 text-sm text-paper/60">WhatsApp: {site.phoneInternational} · {site.hours}</p></div><div className="flex flex-col gap-3 sm:flex-row lg:justify-end"><a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp</a><Link href="/iletisim#talep-formu" className="btn btn-light">Form ile ulaşın</Link></div></div>
      </section>
    </>
  );
}
