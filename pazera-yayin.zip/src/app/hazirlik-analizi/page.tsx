import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/page-hero";
import { ReadinessQuiz } from "@/components/readiness-quiz";
import { Icon } from "@/components/icon";
import { whatsappUrl } from "@/content/site";

export const metadata: Metadata = {
  title: "İhracat Hazırlık Analizi",
  description: "Ürün, pazar, belge, alıcı, operasyon ve marka başlıklarında ihracat hazırlığınızı değerlendirin. Öncelikli hizmet önerisini görün.",
};

export default function ReadinessPage() {
  return (
    <>
      <PageHero label="Ücretsiz araç" title={<>İhracata ne kadar <em>hazırsınız</em>?</>} breadcrumb={[{ label: "Hazırlık Analizi" }]}>
        <div><p className="text-sm leading-relaxed text-ink/60">Altı soruda ürün, pazar, belge, alıcı, operasyon ve sunum hazırlığınızı puanlayın. Sonuç ekranda görünür; isterseniz ekibimizin değerlendirmesi için kaydedebilirsiniz.</p><div className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-xs text-ink/50"><span>✓ Kayıt gerekmez</span><span>✓ Anında sonuç</span><span>✓ Firmaya özel yönlendirme</span></div></div>
      </PageHero>

      <section className="bg-bone py-12 md:py-16">
        <div className="wrap grid gap-8 lg:grid-cols-[1.35fr_0.65fr] lg:gap-12">
          <ReadinessQuiz />
          <aside className="space-y-5">
            <div className="rounded-md border border-ink/12 bg-paper p-6"><p className="eyebrow text-copper-dark">Nasıl hesaplanıyor?</p><ul className="mt-4 space-y-4 text-sm leading-relaxed text-ink/65"><li className="flex gap-3"><span className="text-[0.625rem] font-bold text-copper-dark">01</span>Her soru 0–3 arası puanlanır; toplam 18 puan 100’lük skora dönüştürülür.</li><li className="flex gap-3"><span className="text-[0.625rem] font-bold text-copper-dark">02</span>En düşük puanlı başlık, öncelikli çalışma alanı olarak belirlenir.</li><li className="flex gap-3"><span className="text-[0.625rem] font-bold text-copper-dark">03</span>Sonuç, yanıtlarınız üzerinden yorumlanır; kesin bir satış veya ihracat garantisi değildir.</li></ul></div>
            <div className="rounded-md bg-ink p-6 text-paper"><p className="display text-2xl leading-snug">Skorunuz düşükse bu bir sorun değil; <span className="text-copper">sıra</span> meselesi.</p><p className="mt-3 text-xs leading-relaxed text-paper/60">Hazırlık sırası doğru kurulduğunda ilk adımları daha planlı atabilirsiniz. Hangi hizmetle başlamanız gerektiğini birlikte netleştirelim.</p><a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary mt-5 w-full"><Icon name="whatsapp" className="h-4 w-4" /> WhatsApp ile görüşelim</a></div>
            <div className="rounded-md border border-ink/12 bg-paper p-6"><p className="eyebrow text-copper-dark">Gizlilik</p><p className="mt-2 text-xs leading-relaxed text-ink/55">Yanıtlarınız yalnızca hazırlık değerlendirmesi için kullanılır. E-posta vermeden de analizi tamamlayabilirsiniz.</p></div>
          </aside>
        </div>
      </section>

      <section className="border-t border-ink/10 bg-paper py-14"><div className="wrap grid gap-8 sm:grid-cols-3">{[{ title: "Önce ürün ve pazar", detail: "Ürününüzün hedef pazardaki karşılığını netleştirmeden alıcı iletişimine geçmeyin." }, { title: "Operasyonu birlikte düşünün", detail: "Teslim şekli, belge akışı, lojistik ve nakliye kararları fiyatı ve süreci birlikte etkiler." }, { title: "Sunumu ihmal etmeyin", detail: "Web sitesi ve katalog, alıcının firmanızı tanıdığı ilk alanlardır; bilgi tutarlılığı önemlidir." }].map((item, index) => <div key={item.title} className="border-t border-ink/12 pt-5"><p className="text-[0.625rem] font-bold tracking-[0.16em] text-copper-dark">0{index + 1}</p><h3 className="display mt-3 text-xl text-ink">{item.title}</h3><p className="mt-2 text-sm leading-relaxed text-ink/60">{item.detail}</p></div>)}</div></section>
    </>
  );
}
