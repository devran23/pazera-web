import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/page-hero";
import { Icon } from "@/components/icon";
import { OfficeCards } from "@/components/office-cards";
import { faqs, site, stats, team, values, whatsappUrl } from "@/content/site";

export const metadata: Metadata = {
  title: "Hakkımızda",
  description: "Pazera; 5 yıldır ihracatın içinde, 100 firma ile çalışan dış ticaret firmasıdır. Kurucu Devran Taşpınar ve ekip görev alanlarını tanıyın.",
};

export default function AboutPage() {
  const founder = team[0];
  const members = team.slice(1);

  return (
    <>
      <PageHero label="Hakkımızda" title={<>5 yıldır ihracatın içinde, <em>100 firma</em> ile yan yana.</>} breadcrumb={[{ label: "Hakkımızda" }]}>
        <p className="text-sm leading-relaxed text-ink/60">Pazera Dış Ticaret; analiz, operasyon ve tasarım başlıklarını firmaların ihracat hedefleriyle birlikte ele alır. Gana, Suudi Arabistan ve Suriye olmak üzere 3 ofisimiz bulunur.</p>
      </PageHero>

      <section className="bg-paper py-16 md:py-24">
        <div className="wrap grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
          <div><p className="eyebrow text-copper-dark">Biz kimiz?</p><h2 className="display mt-4 text-[clamp(2rem,3.8vw,3rem)] text-ink">Ticaretin farklı adımlarını <em>tek plan</em> altında buluşturuyoruz.</h2><div className="mt-6 space-y-4 text-[0.9375rem] leading-[1.8] text-ink/70"><p>Pazera olarak 5 yıldır ihracatın içindeyiz ve 100 firma ile çalışıyoruz. Ürün analizi, pazar araştırması, rakip ve fiyat incelemesi gibi karar destek hizmetlerini; gümrük, lojistik ve nakliye danışmanlığıyla birlikte yürütüyoruz.</p><p>Web sitesi ve katalog tasarımıyla firmaların yurt dışındaki sunumunu destekliyor, ihtiyaç halinde alıcı geliştirme, süreç danışmanlığı ve marka/ambalaj başlıklarını da kapsama ekliyoruz.</p><p>Her firmanın ihtiyacı farklıdır. Bu nedenle hizmet kapsamını ve fiyatı, firmaya özel yapılan analizlere göre belirliyoruz.</p></div><a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="btn btn-primary mt-7"><Icon name="whatsapp" className="h-4 w-4" /> Ekibimizle görüşün</a></div>
          <div className="overflow-hidden rounded-md border border-copper/25 bg-ink"><img src={site.logo} alt="Pazera Dış Ticaret logosu" className="h-auto w-full" /></div>
        </div>
      </section>

      <section className="border-y border-ink/10 bg-bone py-12"><dl className="wrap grid grid-cols-2 gap-y-8 lg:grid-cols-4">{stats.map((stat) => <div key={stat.label} className="lg:border-l lg:border-ink/10 lg:pl-6 lg:first:border-l-0 lg:first:pl-0"><dd className="display text-[2.5rem] leading-none text-ink">{stat.value}<span className="ml-1.5 text-base text-copper-dark">{stat.suffix}</span></dd><dt className="mt-2 text-xs text-ink/50">{stat.label}</dt></div>)}</dl></section>

      <section className="bg-paper py-16 md:py-24">
        <div className="wrap grid gap-12 lg:grid-cols-[0.85fr_1.15fr]"><div><p className="eyebrow text-copper-dark">Yaklaşımımız</p><h2 className="display mt-4 text-[clamp(2rem,3.6vw,2.8rem)] text-ink">Nasıl çalıştığımızı belirleyen <em>dört ilke</em>.</h2></div><div className="border-t border-ink/12">{values.map((value, index) => <div key={value.title} className="border-b border-ink/12 py-6"><div className="flex gap-5"><span className="mt-1 text-[0.6875rem] font-bold tracking-[0.16em] text-copper-dark">0{index + 1}</span><div><h3 className="text-lg font-semibold text-ink">{value.title}</h3><p className="mt-2 text-sm leading-relaxed text-ink/60">{value.detail}</p></div></div></div>)}</div></div>
      </section>

      <section className="bg-bone py-16 md:py-24">
        <div className="wrap">
          <div className="max-w-2xl"><p className="eyebrow text-copper-dark">Ekibimiz</p><h2 className="display mt-4 text-[clamp(2rem,3.8vw,3rem)] text-ink">Sizinle ilgilenecek <em>ekip arkadaşlarımız</em>.</h2><p className="mt-4 text-sm leading-relaxed text-ink/60">Talebiniz, ihtiyacınıza göre ilgili ekip arkadaşımıza yönlendirilir.</p></div>
          <article className="mt-10 grid gap-8 rounded-md bg-ink p-8 text-paper md:grid-cols-[0.7fr_1.3fr] md:items-center">
            <div className="flex items-center gap-5"><span className="display grid h-24 w-24 shrink-0 place-items-center rounded-full border border-copper/40 bg-copper/10 text-3xl text-copper">{founder.initials}</span><div><p className="eyebrow text-copper">Kurucu</p><h3 className="display mt-2 text-3xl">{founder.name}</h3><p className="mt-1 text-sm text-paper/60">{founder.role}</p></div></div>
            <div><p className="text-sm leading-relaxed text-paper/70">{founder.bio}</p><div className="mt-4 flex flex-wrap gap-2">{founder.tags.map((tag) => <span key={tag} className="rounded border border-paper/20 px-2.5 py-1 text-[0.5625rem] uppercase tracking-[0.12em] text-paper/60">{tag}</span>)}</div></div>
          </article>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{members.map((person) => <article key={person.name} className="card-line rounded-md p-6"><span className="display grid h-14 w-14 place-items-center rounded-full border border-copper/30 bg-copper/8 text-lg text-copper-dark">{person.initials}</span><h3 className="mt-5 text-lg font-semibold text-ink">{person.name}</h3><p className="mt-1 text-[0.6875rem] font-bold uppercase tracking-[0.1em] text-copper-dark">{person.role}</p><p className="mt-3 text-sm leading-relaxed text-ink/60">{person.bio}</p></article>)}</div>
        </div>
      </section>

      <section className="bg-paper py-16 md:py-24"><div className="wrap"><div className="max-w-2xl"><p className="eyebrow text-copper-dark">Ofislerimiz</p><h2 className="display mt-4 text-[clamp(2rem,3.8vw,3rem)] text-ink">Gana, Suudi Arabistan ve <em>Suriye</em>.</h2></div><div className="mt-10"><OfficeCards showNote /></div></div></section>

      <section className="border-t border-ink/10 bg-bone py-16"><div className="wrap grid gap-10 lg:grid-cols-[0.8fr_1.2fr]"><div><p className="eyebrow text-copper-dark">Sık sorular</p><h2 className="display mt-4 text-[clamp(1.9rem,3.4vw,2.6rem)] text-ink">Merak edilenler.</h2><Link href="/iletisim" className="btn btn-dark mt-6">Sorunuzu iletin</Link></div><div className="border-t border-ink/12">{faqs.map((faq) => <details key={faq.q} className="group border-b border-ink/12 py-5"><summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-[0.9375rem] font-semibold text-ink">{faq.q}<span className="text-copper-dark transition-transform group-open:rotate-45">+</span></summary><p className="mt-3 text-sm leading-relaxed text-ink/60">{faq.a}</p></details>)}</div></div></section>
    </>
  );
}
