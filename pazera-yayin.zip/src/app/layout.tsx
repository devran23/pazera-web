import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { Icon } from "@/components/icon";
import { offices, services, site, whatsappUrl } from "@/content/site";
import { getSiteUrl } from "@/lib/site-url";

const publicUrl = getSiteUrl();

export const metadata: Metadata = {
  metadataBase: new URL(publicUrl),
  title: { default: "Pazera Dış Ticaret · Dünyaya Açılan Ticaret Kapınız", template: "%s · Pazera" },
  description: site.description,
  keywords: ["Pazera", "dış ticaret", "ihracat danışmanlığı", ...services.map((service) => service.title)],
  icons: { icon: site.mark, apple: site.mark },
  openGraph: {
    title: "Pazera Dış Ticaret",
    description: site.tagline,
    type: "website",
    locale: "tr_TR",
    siteName: "Pazera",
    images: [{ url: site.logo, width: 1000, height: 680, alt: "Pazera Dış Ticaret logosu" }],
  },
  robots: { index: true, follow: true },
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: site.name,
  legalName: site.legalName,
  description: site.description,
  slogan: site.tagline,
  url: publicUrl,
  logo: `${publicUrl}${site.logo}`,
  telephone: site.phoneInternational,
  areaServed: offices.map((office) => ({ "@type": "Country", name: office.country })),
  knowsAbout: services.map((service) => service.title),
  founder: { "@type": "Person", name: "Devran Taşpınar" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@1,500;1,600&family=Manrope:wght@300..800&display=swap" rel="stylesheet" />
      </head>
      <body className="flex min-h-screen flex-col bg-bone text-ink antialiased">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
        <a
          href={whatsappUrl()}
          target="_blank"
          rel="noreferrer noopener"
          aria-label={`WhatsApp ile yazın: ${site.phone}`}
          className="fixed bottom-5 right-5 z-40 flex items-center gap-2.5 rounded-full border border-copper/40 bg-ink px-4 py-3.5 text-paper shadow-[0_12px_36px_rgba(6,26,56,0.28)] transition-all hover:-translate-y-1 hover:border-copper hover:bg-ink-soft sm:bottom-7 sm:right-7"
        >
          <Icon name="whatsapp" className="h-6 w-6 text-copper" />
          <span className="hidden text-xs font-bold uppercase tracking-[0.08em] sm:inline">WhatsApp ile yazın</span>
        </a>
      </body>
    </html>
  );
}
