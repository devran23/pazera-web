import type { Metadata } from "next";
import Link from "next/link";
import { cookies } from "next/headers";
import { ADMIN_COOKIE, adminConfigured, validSessionToken } from "@/lib/admin-auth";
import { AdminLogin } from "@/components/admin-login";
import { AdminLogout } from "@/components/admin-logout";
import { db } from "@/db";
import { leads as leadsTable, readinessChecks, subscribers } from "@/db/schema";
import { desc } from "drizzle-orm";
import { LeadTable, type PanelLead } from "@/components/lead-table";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Talep Paneli",
  description: "Pazera ekibi için gelen talep, bülten ve hazırlık analizi kayıtları.",
  robots: { index: false, follow: false },
};

const FILTERS = [
  { value: "tumu", label: "Tümü" },
  { value: "yeni", label: "Yeni" },
  { value: "gorusuluyor", label: "Görüşülüyor" },
  { value: "teklif", label: "Teklif" },
  { value: "kazanildi", label: "Kazanıldı" },
  { value: "arsiv", label: "Arşiv" },
];

type PageProps = { searchParams: Promise<{ durum?: string }> };

type ReadinessRow = {
  id: number;
  company: string | null;
  email: string | null;
  score: number;
  level: string;
  focus: string | null;
  createdAt: Date;
};

export default async function PanelPage({ searchParams }: PageProps) {
  const jar = await cookies();
  if (!validSessionToken(jar.get(ADMIN_COOKIE)?.value)) {
    return <AdminLogin configured={adminConfigured()} />;
  }

  const { durum } = await searchParams;
  const activeFilter = FILTERS.some((filter) => filter.value === durum) ? durum! : "tumu";

  let panelLeads: PanelLead[] = [];
  let subscriberRows: { id: number; email: string; source: string; createdAt: Date }[] = [];
  let readinessRows: ReadinessRow[] = [];
  let dbError = "";

  try {
    const [leadRows, subs, checks] = await Promise.all([
      db.select().from(leadsTable).orderBy(desc(leadsTable.createdAt)).limit(200),
      db.select().from(subscribers).orderBy(desc(subscribers.createdAt)).limit(50),
      db
        .select({
          id: readinessChecks.id,
          company: readinessChecks.company,
          email: readinessChecks.email,
          score: readinessChecks.score,
          level: readinessChecks.level,
          focus: readinessChecks.focus,
          createdAt: readinessChecks.createdAt,
        })
        .from(readinessChecks)
        .orderBy(desc(readinessChecks.createdAt))
        .limit(30),
    ]);

    panelLeads = leadRows.map((lead) => ({
      ...lead,
      createdAt: lead.createdAt.toISOString(),
    }));
    subscriberRows = subs;
    readinessRows = checks;
  } catch {
    dbError = "Veritabanına ulaşılamadı. Şema hazır olduğunda kayıtlar burada görünecek.";
  }

  const filteredLeads =
    activeFilter === "tumu" ? panelLeads : panelLeads.filter((lead) => lead.status === activeFilter);

  const newCount = panelLeads.filter((lead) => lead.status === "yeni").length;
  const wonCount = panelLeads.filter((lead) => lead.status === "kazanildi").length;
  const avgReadiness =
    readinessRows.length > 0
      ? Math.round(readinessRows.reduce((sum, row) => sum + row.score, 0) / readinessRows.length)
      : 0;

  const statCards = [
    { label: "Toplam talep", value: panelLeads.length, note: "son 200 kayıt" },
    { label: "Yeni talep", value: newCount, note: "yanıt bekliyor" },
    { label: "Kazanılan", value: wonCount, note: "aktif müşteri" },
    { label: "Bülten abonesi", value: subscriberRows.length, note: "son 50 kayıt" },
    { label: "Ortalama hazırlık skoru", value: avgReadiness, note: "son 30 analiz" },
  ];

  return (
    <>
      <section className="relative overflow-hidden bg-ink text-paper">
        <div className="map-grid absolute inset-0 opacity-60" aria-hidden="true" />
        <div className="wrap relative py-12 md:py-16">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="eyebrow text-copper">Pazera · dahili çalışma alanı</p>
              <h1 className="display mt-4 text-[clamp(2rem,4.2vw,3.2rem)] text-paper">Talep Paneli</h1>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-paper/60">
                Web sitesi formlarından gelen talepler, bülten kayıtları ve hazırlık analizi
                sonuçları. Durum değişiklikleri anında veritabanına yazılır.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <Link href="/" className="btn btn-light">Siteye dön</Link>
              <AdminLogout />
            </div>
          </div>

          <dl className="mt-10 grid grid-cols-2 gap-y-6 border-t border-paper/15 pt-8 sm:grid-cols-3 lg:grid-cols-5">
            {statCards.map((card) => (
              <div key={card.label} className="lg:border-l lg:border-paper/12 lg:pl-5 lg:first:border-l-0 lg:first:pl-0">
                <dd className="display text-[2.2rem] leading-none text-paper">{card.value}</dd>
                <dt className="mt-2 text-xs text-paper/55">{card.label}</dt>
                <p className="text-[0.625rem] uppercase tracking-[0.1em] text-paper/30">{card.note}</p>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className="bg-bone py-10 md:py-14">
        <div className="wrap space-y-10">
          {dbError && (
            <p className="border border-copper/30 bg-copper/5 px-4 py-3 text-sm text-copper">
              {dbError}
            </p>
          )}

          <div>
            <div className="flex flex-wrap items-end justify-between gap-4">
              <h2 className="display text-2xl text-ink">Görüşme talepleri</h2>
              <div className="flex flex-wrap gap-1.5">
                {FILTERS.map((filter) => (
                  <Link
                    key={filter.value}
                    href={filter.value === "tumu" ? "/panel" : `/panel?durum=${filter.value}`}
                    className={`border px-3 py-1.5 text-[0.625rem] font-bold uppercase tracking-[0.1em] transition-colors ${
                      activeFilter === filter.value
                        ? "border-ink bg-ink text-paper"
                        : "border-ink/15 text-ink/55 hover:border-ink/40"
                    }`}
                  >
                    {filter.label}
                  </Link>
                ))}
              </div>
            </div>

            <div className="mt-5">
              <LeadTable leads={filteredLeads} />
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div className="border border-ink/12 bg-paper p-6">
              <div className="flex items-baseline justify-between gap-3">
                <h2 className="display text-xl text-ink">Hazırlık analizi sonuçları</h2>
                <span className="text-[0.625rem] uppercase tracking-[0.12em] text-ink/40">
                  {readinessRows.length} kayıt
                </span>
              </div>
              {readinessRows.length === 0 ? (
                <p className="mt-4 text-sm text-ink/50">
                  Henüz analiz tamamlanmadı.{" "}
                  <Link href="/hazirlik-analizi" className="text-copper underline">
                    Analizi test edin
                  </Link>
                  .
                </p>
              ) : (
                <div className="mt-4 divide-y divide-ink/10">
                  {readinessRows.map((row) => (
                    <div key={row.id} className="flex items-center justify-between gap-4 py-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-ink">
                          {row.company ?? "Firma belirtilmedi"}
                        </p>
                        <p className="truncate text-xs text-ink/45">{row.email ?? "e-posta yok"}</p>
                        <p className="mt-0.5 truncate text-[0.6875rem] text-ink/50">{row.focus}</p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p className="display text-xl text-copper">{row.score}</p>
                        <p className="text-[0.5625rem] uppercase tracking-[0.1em] text-ink/40">
                          {row.level}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="border border-ink/12 bg-paper p-6">
              <div className="flex items-baseline justify-between gap-3">
                <h2 className="display text-xl text-ink">Bülten aboneleri</h2>
                <span className="text-[0.625rem] uppercase tracking-[0.12em] text-ink/40">
                  {subscriberRows.length} kayıt
                </span>
              </div>
              {subscriberRows.length === 0 ? (
                <p className="mt-4 text-sm text-ink/50">
                  Henüz abone yok. Alt bölümdeki form ile kayıt oluşturabilirsiniz.
                </p>
              ) : (
                <ul className="mt-4 divide-y divide-ink/10">
                  {subscriberRows.map((row) => (
                    <li key={row.id} className="flex items-center justify-between gap-3 py-2.5">
                      <span className="truncate text-sm text-ink/70">{row.email}</span>
                      <span className="shrink-0 text-[0.5625rem] uppercase tracking-[0.1em] text-ink/35">
                        {row.source}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              <p className="mt-5 border-t border-ink/10 pt-4 text-[0.6875rem] leading-relaxed text-ink/40">
                Bu panel dahili kullanım için tasarlanmıştır. Üretim ortamında kimlik doğrulama ve
                rol bazlı erişim eklenmelidir.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
