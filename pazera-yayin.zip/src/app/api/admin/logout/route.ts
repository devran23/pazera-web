import { cookies } from "next/headers";
import { ADMIN_COOKIE, sameOrigin, sessionCookieOptions } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return Response.json({ ok: false, error: "Geçersiz istek kaynağı." }, { status: 403 });
  }
  const jar = await cookies();
  jar.set(ADMIN_COOKIE, "", { ...sessionCookieOptions, maxAge: 0 });
  return Response.json({ ok: true });
}
