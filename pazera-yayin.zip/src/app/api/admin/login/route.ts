import { cookies } from "next/headers";
import {
  ADMIN_COOKIE,
  adminConfigured,
  createSessionToken,
  passwordMatches,
  sameOrigin,
  sessionCookieOptions,
} from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return Response.json({ ok: false, error: "Geçersiz istek kaynağı." }, { status: 403 });
  }
  if (!adminConfigured()) {
    return Response.json(
      { ok: false, error: "Panel erişimi henüz yapılandırılmadı. Hosting ayarlarına ADMIN_PASSWORD ve ADMIN_SESSION_SECRET ekleyin." },
      { status: 503 },
    );
  }

  let password = "";
  try {
    const body = (await request.json()) as { password?: unknown };
    password = typeof body.password === "string" ? body.password.slice(0, 500) : "";
  } catch {
    return Response.json({ ok: false, error: "Geçersiz istek." }, { status: 400 });
  }

  if (!passwordMatches(password)) {
    return Response.json({ ok: false, error: "Şifre hatalı." }, { status: 401 });
  }

  const jar = await cookies();
  jar.set(ADMIN_COOKIE, createSessionToken(), sessionCookieOptions);
  return Response.json({ ok: true });
}
