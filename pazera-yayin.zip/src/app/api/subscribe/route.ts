import { db } from "@/db";
import { subscribers } from "@/db/schema";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(request: Request) {
  let email = "";
  let source = "footer";

  try {
    const body = (await request.json()) as { email?: unknown; source?: unknown };
    email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    source = typeof body.source === "string" ? body.source.trim().slice(0, 60) : "footer";
  } catch {
    return Response.json({ ok: false, error: "Geçersiz istek." }, { status: 400 });
  }

  if (!EMAIL_RE.test(email) || email.length > 200) {
    return Response.json({ ok: false, error: "Geçerli bir e-posta adresi girin." }, { status: 422 });
  }

  try {
    const inserted = await db
      .insert(subscribers)
      .values({ email, source })
      .onConflictDoNothing({ target: subscribers.email })
      .returning({ id: subscribers.id });

    if (inserted.length === 0) {
      return Response.json({ ok: true, message: "Bu adres zaten listemizde yer alıyor." });
    }

    return Response.json(
      { ok: true, message: "Teşekkürler! İlk ihracat notu önümüzdeki hafta gelecek." },
      { status: 201 },
    );
  } catch {
    return Response.json({ ok: false, error: "Kayıt tamamlanamadı." }, { status: 500 });
  }
}
