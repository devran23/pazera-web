import { db } from "@/db";
import { readinessChecks } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let payload: {
    company?: unknown;
    email?: unknown;
    score?: unknown;
    level?: unknown;
    focus?: unknown;
    answers?: unknown;
  };

  try {
    payload = (await request.json()) as typeof payload;
  } catch {
    return Response.json({ ok: false, error: "Geçersiz istek." }, { status: 400 });
  }

  const score = Number(payload.score);
  if (!Number.isFinite(score) || score < 0 || score > 100) {
    return Response.json({ ok: false, error: "Geçersiz skor." }, { status: 422 });
  }

  const level =
    typeof payload.level === "string" ? payload.level.trim().slice(0, 40) : "Başlangıç";
  const focus = typeof payload.focus === "string" ? payload.focus.trim().slice(0, 200) : null;
  const company =
    typeof payload.company === "string" ? payload.company.trim().slice(0, 180) : null;
  const email =
    typeof payload.email === "string" ? payload.email.trim().toLowerCase().slice(0, 200) : null;
  const answers =
    payload.answers && typeof payload.answers === "object"
      ? (payload.answers as Record<string, number>)
      : {};

  try {
    const [row] = await db
      .insert(readinessChecks)
      .values({
        score: Math.round(score),
        level,
        focus,
        company: company || null,
        email: email || null,
        answers,
      })
      .returning({ id: readinessChecks.id });

    return Response.json({ ok: true, id: row?.id }, { status: 201 });
  } catch {
    return Response.json({ ok: false, error: "Sonuç kaydedilemedi." }, { status: 500 });
  }
}
