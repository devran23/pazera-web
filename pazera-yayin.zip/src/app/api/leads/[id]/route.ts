import { cookies } from "next/headers";
import { db } from "@/db";
import { leads } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ADMIN_COOKIE, sameOrigin, validSessionToken } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

const STATUSES = ["yeni", "gorusuluyor", "teklif", "kazanildi", "arsiv"] as const;

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const jar = await cookies();
  if (!validSessionToken(jar.get(ADMIN_COOKIE)?.value)) {
    return Response.json({ ok: false, error: "Bu işlem için panel girişi gerekli." }, { status: 401 });
  }
  if (!sameOrigin(request)) {
    return Response.json({ ok: false, error: "Geçersiz istek kaynağı." }, { status: 403 });
  }

  const { id } = await params;
  const leadId = Number(id);

  if (!Number.isInteger(leadId) || leadId <= 0) {
    return Response.json({ ok: false, error: "Geçersiz talep." }, { status: 400 });
  }

  let status = "";
  try {
    const body = (await request.json()) as { status?: unknown };
    status = typeof body.status === "string" ? body.status : "";
  } catch {
    return Response.json({ ok: false, error: "Geçersiz istek." }, { status: 400 });
  }

  if (!STATUSES.includes(status as (typeof STATUSES)[number])) {
    return Response.json({ ok: false, error: "Geçersiz durum." }, { status: 422 });
  }

  try {
    const [row] = await db
      .update(leads)
      .set({ status })
      .where(eq(leads.id, leadId))
      .returning();

    if (!row) {
      return Response.json({ ok: false, error: "Talep bulunamadı." }, { status: 404 });
    }

    return Response.json({ ok: true, lead: row });
  } catch {
    return Response.json({ ok: false, error: "Güncelleme başarısız." }, { status: 500 });
  }
}
