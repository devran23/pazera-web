import { cookies } from "next/headers";
import { db } from "@/db";
import { leads } from "@/db/schema";
import { desc } from "drizzle-orm";
import { packages } from "@/content/site";
import { ADMIN_COOKIE, validSessionToken } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function clean(value: unknown, max = 500): string {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

export async function GET() {
  const jar = await cookies();
  if (!validSessionToken(jar.get(ADMIN_COOKIE)?.value)) {
    return Response.json({ ok: false, error: "Bu işlem için panel girişi gerekli." }, { status: 401 });
  }

  try {
    const rows = await db.select().from(leads).orderBy(desc(leads.createdAt)).limit(200);
    return Response.json({ ok: true, leads: rows });
  } catch {
    return Response.json({ ok: false, error: "Talepler okunamadı." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  let payload: Record<string, unknown>;
  try {
    payload = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Geçersiz istek." }, { status: 400 });
  }

  const name = clean(payload.name, 160);
  const email = clean(payload.email, 200).toLowerCase();
  const message = clean(payload.message, 4000);
  const honeypot = clean(payload.website, 200);
  const packageId = clean(payload.packageName ?? payload.package, 40);
  const selectedPackage = packages.find((pkg) => pkg.id === packageId);

  if (honeypot) return Response.json({ ok: true, message: "Talebiniz alındı." });

  const errors: Record<string, string> = {};
  if (name.length < 2) errors.name = "Ad soyad en az 2 karakter olmalı.";
  if (!EMAIL_RE.test(email)) errors.email = "Geçerli bir e-posta adresi girin.";
  if (message.length < 10) errors.message = "Lütfen projenizi en az 10 karakterle anlatın.";
  if (packageId && !selectedPackage) errors.packageName = "Geçerli bir paket seçin.";

  if (Object.keys(errors).length > 0) {
    return Response.json({ ok: false, errors, error: "Lütfen formu kontrol edin." }, { status: 422 });
  }

  try {
    const [row] = await db.insert(leads).values({
      name,
      email,
      company: clean(payload.company, 180) || null,
      phone: clean(payload.phone, 60) || null,
      country: clean(payload.country, 120) || null,
      service: clean(payload.service, 160) || null,
      packageName: selectedPackage?.id ?? null,
      volume: clean(payload.volume, 120) || null,
      message,
      source: clean(payload.source, 60) || "website",
    }).returning({ id: leads.id });

    return Response.json({ ok: true, id: row?.id, message: "Talebiniz Pazera ekibine ulaştı. İlgili ekip arkadaşımız sizinle iletişime geçecek." }, { status: 201 });
  } catch {
    return Response.json({ ok: false, error: "Kayıt sırasında bir sorun oluştu. Lütfen tekrar deneyin." }, { status: 500 });
  }
}
