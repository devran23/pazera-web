import type { Metadata } from "next";
import Link from "next/link";
import { PageHero } from "@/components/page-hero";
import { LeadForm } from "@/components/lead-form";
import { Icon } from "@/components/icon";
import { OfficeCards } from "@/components/office-cards";
import { faqs, packages, services, site, whatsappUrl } from "@/content/site";

export const metadata: Metadata = {
  title: "İletişim ve Ofislerimiz",
  description: "Pazera Dış Ticaret ile WhatsApp veya form üzerinden görüşün. Gana, Suudi Arabistan ve Suriye ofislerimiz; 0546 401 28 83 iletişim numarası.",
};

type PageProps = { searchParams: Promise<{ hizmet?: string; paket?: string }> };

export default async function ContactPage({ searchParams }: PageProps) {
  const { hizmet, paket } = await searchParams;
  const selectedService = services.find((service) => service.slug === hizmet);
  const selectedPackage = packages.find((item) => item.id === paket);

  return (
    <>
      <PageHero label="İletişim" title={<>Firmanız için <em>doğru kapsamı</em> birlikte belirleyelim.</>} breadcrumb={[{ label: "İletişim" }]}>
        <p className="text-sm leading-relaxed text-ink/60">WhatsApp üzerinden yazabilir veya formu doldurabilirsiniz. Talebiniz, ihtiyacınıza göre ilgili ekip arkadaşımıza yönlendirilir. Fiyatlar firmaya özel analiz sonrası belirlenir.</p>
      </PageHero>

      <section className="bg-bone py-14 md:py-20">
        <div className="wrap grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-14">
          <div className="space-y-5">
            <a href={whatsappUrl()} target="_blank" rel="noreferrer noopener" className="card-line flex items-start gap-4 rounded-md p-6"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-copper/12 text-copper-dark"><Icon name="whatsapp" className="h-6 w-6" /></span><div><p className="eyebrow text-copper-dark">WhatsApp</p><p className="mt-2 text-lg font-semibold text-ink">{site.phone}</p><p className="mt-1 text-xs text-ink/50">Uluslararası: {site.phoneInternational}</p><span className="mt-3 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.1em] text-ink">Sohbeti başlat <Icon name="arrow" className="h-3.5 w-3.5" /></span></div></a>
            <a href={`tel:${site.phoneInternational.replace(/\s/g, "")}`} className="card-line flex items-start gap-4 rounded-md p-6"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-ink/5 text-ink"><Icon name="phone" className="h-5 w-5" /></span><div><p className="eyebrow text-ink/45">Telefon</p><p className="mt-2 text-lg font-semibold text-ink">{site.phone}</p><p className="mt-1 text-xs text-ink/50">{site.hours}</p></div></a>
            <div className="rounded-md bg-ink p-6 text-paper"><p className="eyebrow text-copper">Görüşmede ne konuşuruz?</p><ul className="mt-4 space-y-3 text-sm leading-relaxed text-paper/70"><li className="flex gap-3"><span className="text-copper">01</span> Ürününüz, hedef pazarınız ve mevcut durumunuz.</li><li className="flex gap-3"><span className="text-copper">02</span> İhtiyaç duyduğunuz hizmetler veya paket.</li><li className="flex gap-3"><span className="text-copper">03</span> Analiz kapsamı ve firmaya özel teklif süreci.</li></ul><p className="mt-5 border-t border-paper/15 pt-4 text-xs text-paper/45">Paket fiyatları sabit değildir; firmanıza özel yapılan analizlere göre değişir.</p></div>
            <div className="rounded-md border border-ink/12 bg-paper p-5"><p className="text-sm font-semibold text-ink">Nereden başlayacağınızı bilmiyor musunuz?</p><p className="mt-1.5 text-xs leading-relaxed text-ink/55">Hazırlık analizi, öncelikli başlığınızı görmenize yardımcı olur.</p><Link href="/hazirlik-analizi" className="mt-3 inline-block text-xs font-bold uppercase tracking-[0.1em] text-copper-dark">Hazırlık analizini başlat →</Link></div>
          </div>

          <div id="talep-formu" className="scroll-mt-32 rounded-md border border-ink/12 bg-paper p-6 sm:p-9">
            <p className="eyebrow text-copper-dark">Teklif / görüşme talebi</p>
            <h2 className="display mt-3 text-[clamp(1.7rem,3vw,2.4rem)] text-ink">Formu doldurun, <em>ekibimiz ulaşsın</em>.</h2>
            {selectedPackage && <p className="mt-4 rounded-md border border-copper/30 bg-copper/8 px-4 py-3 text-sm text-ink">Seçilen paket: <strong>{selectedPackage.name}</strong> · {selectedPackage.subtitle}. Kapsam ve fiyat analiz sonrası netleşir.</p>}
            <div className="mt-7"><LeadForm initialService={selectedService?.title ?? ""} initialPackage={selectedPackage?.id ?? ""} /></div>
          </div>
        </div>
      </section>

      <section id="ofisler" className="scroll-mt-32 border-t border-ink/10 bg-paper py-16 md:py-20"><div className="wrap"><div className="max-w-2xl"><p className="eyebrow text-copper-dark">Ofislerimiz</p><h2 className="display mt-4 text-[clamp(2rem,3.8vw,3rem)] text-ink">Üç ofisimiz: <em>Gana, Suudi Arabistan, Suriye</em>.</h2></div><div className="mt-10"><OfficeCards showNote /></div></div></section>

      <section className="border-t border-ink/10 bg-bone py-14"><div className="wrap grid gap-10 lg:grid-cols-[0.8fr_1.2fr]"><div><p className="eyebrow text-copper-dark">Kısa yanıtlar</p><h2 className="display mt-4 text-[clamp(1.8rem,3.2vw,2.5rem)] text-ink">İletişim öncesi bilmeniz gerekenler.</h2></div><div className="border-t border-ink/12">{faqs.slice(0, 4).map((faq) => <details key={faq.q} className="group border-b border-ink/12 py-5"><summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-[0.9375rem] font-semibold text-ink">{faq.q}<span className="text-copper-dark transition-transform group-open:rotate-45">+</span></summary><p className="mt-3 text-sm leading-relaxed text-ink/60">{faq.a}</p></details>)}</div></div></section>
    </>
  );
}
