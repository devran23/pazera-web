import Link from "next/link";

export default function NotFound() {
  return (
    <section className="bg-bone py-24 md:py-32">
      <div className="wrap grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-center">
        <div>
          <p className="eyebrow text-copper">404 · Sayfa bulunamadı</p>
          <h1 className="display mt-5 text-[clamp(2.4rem,5vw,4rem)] text-ink">
            Bu rota <em>kapatılmış</em>.
          </h1>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-ink/60">
            Aradığınız sayfa taşınmış veya kaldırılmış olabilir. Hizmetlerimize göz atabilir ya da
            doğrudan bize ulaşabilirsiniz.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link href="/" className="btn btn-primary">
              Ana sayfaya dön
            </Link>
            <Link href="/iletisim" className="btn btn-ghost">
              İletişim
            </Link>
          </div>
        </div>
        <div className="relative overflow-hidden bg-ink">
          <img
            src="https://images.pexels.com/photos/7519246/pexels-photo-7519246.jpeg?auto=compress&cs=tinysrgb&w=1200"
            alt="Liman konteynerleri"
            className="h-[320px] w-full object-cover opacity-70"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent" />
          <p className="absolute bottom-6 left-6 right-6 text-sm text-paper/70">
            &ldquo;Doğru limanı bulmak, yola çıkmadan önce yapılan bir iştir.&rdquo;
          </p>
        </div>
      </div>
    </section>
  );
}
