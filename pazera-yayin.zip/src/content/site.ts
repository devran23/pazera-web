export const site = {
  name: "Pazera",
  legalName: "Pazera Dış Ticaret",
  tagline: "Dünyaya Açılan Ticaret Kapınız..",
  description:
    "Pazera; 5 yıldır ihracatın içinde, 100 firma ile çalışan dış ticaret danışmanlığı firmasıdır. Ürün ve pazar analizinden gümrük, lojistik, nakliye ve tasarım hizmetlerine kadar firmalara özel çözümler sunar.",
  phone: "0546 401 28 83",
  phoneInternational: "+90 546 401 28 83",
  whatsappNumber: "905464012883",
  whatsappMessage:
    "Merhaba Pazera, ihracat hizmetleriniz ve firmama özel çözümünüz hakkında bilgi almak istiyorum.",
  hours: "Görüşme için WhatsApp veya iletişim formu üzerinden ulaşın",
  experienceYears: 5,
  clientCount: 100,
  officeCount: 3,
  logo: "/brand/pazera-logo.svg",
  mark: "/brand/pazera-mark.svg",
};

export function whatsappUrl(message = site.whatsappMessage) {
  return `https://wa.me/${site.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const navigation = [
  { label: "Hizmetler", href: "/hizmetler" },
  { label: "Paketler", href: "/hizmetler#paketler" },
  { label: "Hakkımızda", href: "/hakkimizda" },
  { label: "Ofislerimiz", href: "/iletisim#ofisler" },
  { label: "Bilgi Merkezi", href: "/bilgi-merkezi" },
  { label: "İletişim", href: "/iletisim" },
];

export const stats = [
  { value: "5", suffix: "yıl", label: "İhracat deneyimi" },
  { value: "100", suffix: "firma", label: "Birlikte çalıştığımız firmalar" },
  { value: "3", suffix: "ofis", label: "Gana · Suudi Arabistan · Suriye" },
  { value: "12", suffix: "hizmet", label: "Analizden tasarıma tek çatı" },
];

export const offices = [
  {
    id: "gana",
    country: "Gana",
    region: "Batı Afrika",
    code: "GH",
    title: "Gana Ofisi",
    description:
      "Batı Afrika pazarına yönelik ürün, pazar ve iş geliştirme çalışmalarımızın koordinasyonu.",
    image:
      "https://images.pexels.com/photos/32803403/pexels-photo-32803403.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    imageAlt: "Gana'da Greater Accra bölgesinden şehir görünümü",
  },
  {
    id: "suudi-arabistan",
    country: "Suudi Arabistan",
    region: "Körfez",
    code: "SA",
    title: "Suudi Arabistan Ofisi",
    description:
      "Körfez pazarına açılan firmalar için araştırma, alıcı iletişimi ve operasyon koordinasyonu.",
    image:
      "https://images.pexels.com/photos/38096888/pexels-photo-38096888.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    imageAlt: "Suudi Arabistan'ın başkenti Riyad'dan şehir silüeti",
  },
  {
    id: "suriye",
    country: "Suriye",
    region: "Orta Doğu",
    code: "SY",
    title: "Suriye Ofisi",
    description:
      "Orta Doğu pazarındaki ticari fırsatların değerlendirilmesi ve saha iletişiminin yürütülmesi.",
    image:
      "https://images.pexels.com/photos/34632813/pexels-photo-34632813.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    imageAlt: "Suriye'nin başkenti Şam'dan tarihi ve modern mimari görünümü",
  },
];

export const markets = offices.map((office) => office.country);

export type Service = {
  slug: string;
  no: string;
  title: string;
  short: string;
  hero: string;
  body: string[];
  deliverables: string[];
  outcomes: { label: string; value: string }[];
  idealFor: string[];
  timeline: string;
  image: string;
  keywords: string[];
  icon: string;
  group: string;
  recommended?: boolean;
};

export const services: Service[] = [
  {
    slug: "urun-analizi",
    no: "01",
    title: "Ürün analizi",
    short: "Ürününüzün ihracat potansiyelini, güçlü yönlerini ve geliştirilmesi gereken noktaları netleştiriyoruz.",
    hero: "Doğru pazara çıkmadan önce, ürününüzü doğru okuyun.",
    body: [
      "Ürün analizi; teknik özellikler, kalite algısı, ambalaj, kullanım alanı ve hedef müşteri beklentilerini birlikte değerlendirir. Amacımız ürünün hangi pazarlarda, hangi konumlandırma ile daha güçlü bir karşılık bulabileceğini ortaya koymaktır.",
      "Çalışma sonunda ürününüz için öncelikli geliştirme başlıklarını, hedef pazar uyumunu ve sonraki araştırma adımlarını içeren bir yol haritası sunuyoruz.",
    ],
    deliverables: ["Ürün özellikleri ve kullanım alanı değerlendirmesi", "Hedef müşteri ve pazar uyumu", "Ambalaj ve sunum önerileri", "Geliştirme öncelikleri raporu"],
    outcomes: [{ label: "Odak", value: "Ürün · pazar uyumu" }, { label: "Çıktı", value: "Analiz raporu" }, { label: "Kapsam", value: "Firmaya özel" }],
    idealFor: ["İlk kez ihracat yapacak firmalar", "Yeni ürününü yurt dışına açmak isteyenler", "Mevcut ürününde konumlandırma arayanlar"],
    timeline: "Analiz sonrası netleşir",
    image: "https://images.pexels.com/photos/31212947/pexels-photo-31212947.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["ürün analizi", "ihracat ürün değerlendirmesi"], icon: "box", group: "Analiz & Araştırma",
  },
  {
    slug: "pazar-arastirmasi",
    no: "02",
    title: "Pazar araştırması",
    short: "Hedef ülkelerdeki talebi, müşteri profilini ve pazara giriş koşullarını araştırıyoruz.",
    hero: "Nereye açılacağınızı tahminle değil, araştırma ile belirleyin.",
    body: [
      "Pazar araştırması; hedef ülkedeki talep yapısını, dağıtım kanallarını, müşteri beklentilerini ve ticari giriş koşullarını inceler. Gana, Suudi Arabistan ve Suriye başta olmak üzere firmanızın hedeflediği pazarlara özel çalışma planı kurulur.",
      "Sonuçta öncelikli pazarları, dikkat edilmesi gereken noktaları ve uygulanabilir bir giriş sırasını görürsünüz. Kapsam, ürününüze ve hedeflediğiniz ülkeye göre belirlenir.",
    ],
    deliverables: ["Hedef ülke talep ve müşteri profili", "Dağıtım ve satış kanalı araştırması", "Pazara giriş koşulları özeti", "Öncelikli pazar önerileri"],
    outcomes: [{ label: "Odak", value: "Talep · kanal" }, { label: "Çıktı", value: "Pazar raporu" }, { label: "Kapsam", value: "Ülke bazlı" }],
    idealFor: ["Yeni pazara girecek firmalar", "Mevcut pazarını çeşitlendirmek isteyenler", "Bölgesel büyüme planlayanlar"],
    timeline: "Pazar sayısına göre",
    image: "https://images.pexels.com/photos/1554646/pexels-photo-1554646.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["pazar araştırması", "hedef pazar analizi"], icon: "globe", group: "Analiz & Araştırma",
  },
  {
    slug: "rakip-firma-analizi",
    no: "03",
    title: "Rakip firma analizi",
    short: "Rakiplerinizin ürün, fiyat, kanal ve iletişim yaklaşımını karşılaştırmalı olarak inceliyoruz.",
    hero: "Pazardaki yerinizi görmek için rakiplerinizi de görün.",
    body: [
      "Rakip firma analizi; hedef pazardaki doğrudan ve dolaylı rakipleri, ürün sunumlarını, fiyat yaklaşımlarını ve satış kanallarını karşılaştırır. Böylece nerede farklılaşabileceğinizi ve hangi başlıklarda güçlenmeniz gerektiğini görürsünüz.",
      "Çalışma, firmanızın kendi imkanlarıyla eşleştirilebilir fırsat alanlarını ve öncelikli aksiyonları ortaya çıkarır.",
    ],
    deliverables: ["Rakip firma listesi ve profilleri", "Ürün ve hizmet karşılaştırması", "Fiyat ve kanal yaklaşımı", "Farklılaşma fırsatları"],
    outcomes: [{ label: "Odak", value: "Rekabet · konum" }, { label: "Çıktı", value: "Karşılaştırma" }, { label: "Kapsam", value: "Hedef pazara özel" }],
    idealFor: ["Rekabetin yoğun olduğu pazara girenler", "Farklılaşma arayan markalar", "Satış yaklaşımını gözden geçirenler"],
    timeline: "Rakip sayısına göre",
    image: "https://images.pexels.com/photos/36765719/pexels-photo-36765719.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["rakip analizi", "rekabet araştırması"], icon: "chart", group: "Analiz & Araştırma",
  },
  {
    slug: "fiyat-analizi",
    no: "04",
    title: "Fiyat analizi",
    short: "Maliyet, rakip fiyatları ve hedef pazar beklentilerini birlikte değerlendirerek fiyat kurgusu oluşturuyoruz.",
    hero: "Doğru fiyat, hem rekabetçi hem de sürdürülebilir olmalı.",
    body: [
      "Fiyat analizi; üretim maliyeti, lojistik giderleri, hedef pazar fiyat seviyeleri ve beklenen marjı birlikte ele alır. Amacımız yalnızca düşük fiyat vermek değil, ticari olarak sürdürülebilir bir konumlandırma kurmaktır.",
      "Farklı teslim ve ödeme senaryolarının fiyat üzerindeki etkisini de değerlendirerek teklif hazırlıklarınıza temel oluşturuyoruz.",
    ],
    deliverables: ["Maliyet kalemleri değerlendirmesi", "Rakip fiyat karşılaştırması", "Teslim şekline göre fiyat senaryoları", "Hedef marj ve teklif önerileri"],
    outcomes: [{ label: "Odak", value: "Maliyet · marj" }, { label: "Çıktı", value: "Fiyat çalışması" }, { label: "Kapsam", value: "Ürün bazlı" }],
    idealFor: ["İhracat fiyat listesi hazırlayanlar", "Marjını korumak isteyenler", "Yeni pazara teklif verecek firmalar"],
    timeline: "Ürün grubuna göre",
    image: "https://images.pexels.com/photos/8439649/pexels-photo-8439649.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["fiyat analizi", "ihracat fiyatlandırma"], icon: "tag", group: "Analiz & Araştırma",
  },
  {
    slug: "gumruk-musavirligi",
    no: "05",
    title: "Gümrük müşavirliği",
    short: "İthalat ve ihracat işlemlerinde evrak, süreç ve mevzuat uyumu için danışmanlık sağlıyoruz.",
    hero: "Gümrük süreçlerini planlı, anlaşılır ve takip edilebilir hale getirin.",
    body: [
      "Gümrük müşavirliği kapsamında ürününüze ve hedef ülkeye göre işlem adımları, gerekli belgeler ve dikkat edilmesi gereken uyum başlıkları değerlendirilir. Süreç, firmanızın operasyon ekibiyle koordineli yürütülür.",
      "İşlemlerin kapsamı ve yürütme koşulları dosya bazında incelenir; gerekli yetki ve temsil koşulları teklif aşamasında netleştirilir.",
    ],
    deliverables: ["İşlem ve belge kontrol listesi", "Ürün bazlı süreç değerlendirmesi", "Evrak hazırlık koordinasyonu", "Operasyon ekibiyle takip"],
    outcomes: [{ label: "Odak", value: "Evrak · uyum" }, { label: "Çıktı", value: "Süreç planı" }, { label: "Kapsam", value: "Dosya bazlı" }],
    idealFor: ["İthalat/ihracat işlemi yapacak firmalar", "Evrak sürecini düzenlemek isteyenler", "Operasyon riskini azaltmak isteyenler"],
    timeline: "İşlem dosyasına göre",
    image: "https://images.pexels.com/photos/11678431/pexels-photo-11678431.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["gümrük müşavirliği", "gümrük danışmanlığı"], icon: "fileCheck", group: "Operasyon & Lojistik",
  },
  {
    slug: "lojistik-musavirligi",
    no: "06",
    title: "Lojistik müşavirliği",
    short: "Depolama, dağıtım, tedarik ve sevkiyat akışını maliyet ve verimlilik açısından planlıyoruz.",
    hero: "Ürünün doğru yerde, doğru zamanda olması bir plan işidir.",
    body: [
      "Lojistik müşavirliği; tedarikten teslimata uzanan akışın tamamını değerlendirir. Depolama, stok hareketi, dağıtım kanalı ve sevkiyat planı firmanızın ihtiyaçlarına göre ele alınır.",
      "Amaç, gereksiz maliyetleri ve zaman kayıplarını azaltırken operasyonun öngörülebilirliğini artırmaktır.",
    ],
    deliverables: ["Mevcut lojistik akış analizi", "Depolama ve dağıtım önerileri", "Sevkiyat planlama yaklaşımı", "Maliyet ve verimlilik başlıkları"],
    outcomes: [{ label: "Odak", value: "Akış · verim" }, { label: "Çıktı", value: "Lojistik planı" }, { label: "Kapsam", value: "Operasyona özel" }],
    idealFor: ["Sevkiyat maliyetlerini gözden geçirenler", "Dağıtım ağını büyüten firmalar", "Stok ve teslimat planını iyileştirenler"],
    timeline: "Operasyon kapsamına göre",
    image: "https://images.pexels.com/photos/30824313/pexels-photo-30824313.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["lojistik müşavirliği", "lojistik danışmanlığı"], icon: "route", group: "Operasyon & Lojistik",
  },
  {
    slug: "nakliye-musavirligi",
    no: "07",
    title: "Nakliye müşavirliği",
    short: "Taşıma modeli, rota, navlun ve teslim koşullarını yükünüze uygun şekilde değerlendiriyoruz.",
    hero: "Doğru taşıma kararı, teslimatın da maliyetin de temelidir.",
    body: [
      "Nakliye müşavirliği; yükün özellikleri, çıkış-varış noktaları, teslim süresi ve bütçe dengesine göre taşıma seçeneklerini inceler. Kara, deniz, hava veya çoklu taşıma modelleri karşılaştırmalı ele alınır.",
      "Teklif sürecinde navlun kalemleri, teslim şekli ve operasyon sorumluluklarının netleştirilmesine destek oluyoruz.",
    ],
    deliverables: ["Taşıma modeli karşılaştırması", "Rota ve teslim süresi değerlendirmesi", "Navlun teklif kalemleri analizi", "Teslim şekli koordinasyonu"],
    outcomes: [{ label: "Odak", value: "Rota · navlun" }, { label: "Çıktı", value: "Taşıma önerisi" }, { label: "Kapsam", value: "Yük bazlı" }],
    idealFor: ["Uluslararası sevkiyat planlayanlar", "Taşıma maliyetini karşılaştırmak isteyenler", "Teslim koşullarını netleştiren firmalar"],
    timeline: "Sevkiyat planına göre",
    image: "https://images.pexels.com/photos/6595780/pexels-photo-6595780.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["nakliye müşavirliği", "uluslararası taşıma"], icon: "truck", group: "Operasyon & Lojistik",
  },
  {
    slug: "web-site-tasarimi",
    no: "08",
    title: "Web site tasarımı",
    short: "Firmanızın ihracat hedeflerine uygun, güven veren ve iletişimi kolaylaştıran web siteleri tasarlıyoruz.",
    hero: "Yurt dışındaki alıcı ilk olarak sizi ekranda tanır.",
    body: [
      "Web site tasarımı; firmanızın ürünlerini, hizmetlerini ve iletişim kanallarını anlaşılır bir yapıda sunar. Mobil uyum, hızlı erişim ve net yönlendirme temel önceliklerimizdir.",
      "İhtiyaca göre çok dilli yapı, ürün sayfaları, katalog indirme ve WhatsApp/teklif formları gibi bileşenler kapsamlandırılır.",
    ],
    deliverables: ["Sayfa mimarisi ve tasarım", "Mobil uyumlu arayüz", "Ürün/hizmet içerik yerleşimi", "İletişim ve teklif formları"],
    outcomes: [{ label: "Odak", value: "Güven · erişim" }, { label: "Çıktı", value: "Web sitesi" }, { label: "Kapsam", value: "Sayfa/ihtiyaç bazlı" }],
    idealFor: ["Dijital vitrinini yenilemek isteyenler", "Yurt dışına açılan firmalar", "Teklif talebini kolaylaştırmak isteyenler"],
    timeline: "Sayfa sayısına göre",
    image: "https://images.pexels.com/photos/36765718/pexels-photo-36765718.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["web site tasarımı", "ihracat web sitesi"], icon: "monitor", group: "Tasarım & İletişim",
  },
  {
    slug: "katalog-tasarimi",
    no: "09",
    title: "Katalog tasarımı",
    short: "Ürünlerinizi düzenli, anlaşılır ve profesyonel bir sunumla alıcıya ulaştıran kataloglar hazırlıyoruz.",
    hero: "İyi bir katalog, ürününüzü sizden önce anlatır.",
    body: [
      "Katalog tasarımı; ürün bilgileri, görseller, teknik özellikler ve iletişim detaylarını tutarlı bir düzende birleştirir. Basılı ve dijital kullanım ihtiyaçları birlikte değerlendirilir.",
      "Hedef pazara göre dil, birim ve sunum kurgusu netleştirilir; güncellenebilir bir yapı hedeflenir.",
    ],
    deliverables: ["Katalog sayfa düzeni", "Ürün bilgi ve görsel yerleşimi", "Baskıya uygun dosya", "Dijital paylaşım versiyonu"],
    outcomes: [{ label: "Odak", value: "Sunum · netlik" }, { label: "Çıktı", value: "Katalog" }, { label: "Kapsam", value: "Ürün sayısına göre" }],
    idealFor: ["Ürün portföyünü sunacak firmalar", "Fuar ve alıcı görüşmesine hazırlananlar", "Sunum dilini standartlaştırmak isteyenler"],
    timeline: "Ürün sayısına göre",
    image: "https://images.pexels.com/photos/23496863/pexels-photo-23496863.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["katalog tasarımı", "ürün kataloğu"], icon: "book", group: "Tasarım & İletişim",
  },
  {
    slug: "alici-bulma",
    no: "10",
    title: "Alıcı bulma & iş geliştirme",
    short: "Hedef pazarınızda ürününüze uygun alıcı ve iş ortağı adaylarını araştırıp iletişim planı kuruyoruz.",
    hero: "Doğru alıcıya ulaşmak, doğru araştırmayla başlar.",
    body: [
      "Bu tamamlayıcı hizmette hedef pazarınızdaki potansiyel alıcı, distribütör ve iş ortağı profilleri araştırılır. Adaylar ürün uyumu ve ticari profil açısından değerlendirilir.",
      "İletişim dili, sunum seti ve takip sırası firmanızla birlikte planlanır. Görüşme veya satış garantisi verilmez; çalışma araştırma ve iş geliştirme sürecini destekler.",
    ],
    deliverables: ["Potansiyel alıcı araştırması", "Aday firma profilleri", "İletişim ve sunum planı", "Görüşme takip yaklaşımı"],
    outcomes: [{ label: "Odak", value: "Alıcı · fırsat" }, { label: "Çıktı", value: "Aday listesi" }, { label: "Kapsam", value: "Pazar bazlı" }],
    idealFor: ["Yeni alıcı arayan üreticiler", "Distribütör ağı kurmak isteyenler", "İş ortaklarını çeşitlendiren firmalar"],
    timeline: "Araştırma kapsamına göre",
    image: "https://images.pexels.com/photos/23496863/pexels-photo-23496863.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["alıcı bulma", "ihracat iş geliştirme"], icon: "users", group: "Tamamlayıcı Hizmetler", recommended: true,
  },
  {
    slug: "ihracat-surec-danismanligi",
    no: "11",
    title: "İhracat süreç & belge danışmanlığı",
    short: "Tekliften sevkiyata kadar dış ticaret adımlarını, belge akışını ve sorumlulukları netleştiriyoruz.",
    hero: "Süreci netleşen firmanın operasyonu da rahatlar.",
    body: [
      "Bu tamamlayıcı hizmet; teklif, sözleşme, ödeme, teslim ve sevkiyat adımlarının birbiriyle uyumunu inceler. Firma içi görev paylaşımı ve belge kontrol noktaları görünür hale getirilir.",
      "Amacımız tekrar eden hataları azaltmak ve ekibinizin kullanabileceği anlaşılır bir süreç düzeni kurmaktır.",
    ],
    deliverables: ["Süreç akış haritası", "Belge kontrol listeleri", "Teklif ve teslim uyumu", "Ekip içi görev paylaşımı önerisi"],
    outcomes: [{ label: "Odak", value: "Süreç · kontrol" }, { label: "Çıktı", value: "Akış rehberi" }, { label: "Kapsam", value: "Firmanın yapısına göre" }],
    idealFor: ["İhracat ekibini yeni kuranlar", "Süreçlerini standartlaştırmak isteyenler", "Belge takibini iyileştiren firmalar"],
    timeline: "Süreç kapsamına göre",
    image: "https://images.pexels.com/photos/8439649/pexels-photo-8439649.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["ihracat süreç danışmanlığı", "dış ticaret belge"], icon: "clipboard", group: "Tamamlayıcı Hizmetler", recommended: true,
  },
  {
    slug: "marka-ambalaj-danismanligi",
    no: "12",
    title: "Marka & ambalaj danışmanlığı",
    short: "Hedef pazara uygun marka sunumu, ambalaj bilgileri ve görsel dil için yönlendirme sağlıyoruz.",
    hero: "Raf ve ekran, ürününüzün ilk izlenim alanıdır.",
    body: [
      "Bu tamamlayıcı hizmette marka sunumu, ambalaj üzerindeki bilgiler ve hedef pazar beklentileri birlikte değerlendirilir. Amaç, ürünün ticari kimliğini ve anlaşılabilirliğini güçlendirmektir.",
      "Gerekli tasarım ve içerik çalışmaları web sitesi ve katalog hizmetleriyle uyumlu şekilde kapsamlandırılabilir.",
    ],
    deliverables: ["Marka sunumu değerlendirmesi", "Ambalaj bilgi düzeni önerisi", "Hedef pazar görsel dili", "Ürün sunum tutarlılığı"],
    outcomes: [{ label: "Odak", value: "Kimlik · ambalaj" }, { label: "Çıktı", value: "Yönlendirme" }, { label: "Kapsam", value: "Ürün/marka bazlı" }],
    idealFor: ["Kendi markasıyla açılan firmalar", "Ambalaj sunumunu yenileyenler", "Pazar dilini uyumlamak isteyenler"],
    timeline: "Ürün grubuna göre",
    image: "https://images.pexels.com/photos/31212947/pexels-photo-31212947.jpeg?auto=compress&cs=tinysrgb&w=1600",
    keywords: ["marka danışmanlığı", "ambalaj danışmanlığı"], icon: "palette", group: "Tamamlayıcı Hizmetler", recommended: true,
  },
];

export type ServicePackage = {
  id: string;
  no: string;
  name: string;
  subtitle: string;
  description: string;
  features: string[];
  idealFor: string;
  featured?: boolean;
};

export const packages: ServicePackage[] = [
  {
    id: "baslangic",
    no: "01",
    name: "Başlangıç",
    subtitle: "Pazara hazırlık",
    description: "İhracata nereden başlayacağını netleştirmek isteyen firmalar için analiz odağı.",
    features: ["Ürün analizi", "Pazar araştırması", "Rakip firma analizi", "Fiyat analizi", "İhtiyaç ve öncelik raporu"],
    idealFor: "İlk kez ihracat yapacak veya yeni bir ürün/pazar değerlendirecek firmalar",
  },
  {
    id: "buyume",
    no: "02",
    name: "Büyüme",
    subtitle: "Pazara giriş",
    description: "Analizi ticari sunuma ve alıcı iletişimine taşımak isteyen firmalar için genişletilmiş kapsam.",
    features: ["Başlangıç kapsamına ek olarak", "Alıcı bulma & iş geliştirme", "Web site tasarımı", "Katalog tasarımı", "Pazara giriş yol haritası"],
    idealFor: "Hedef pazarını belirlemiş, görünürlüğünü ve alıcı iletişimini güçlendirmek isteyen firmalar",
    featured: true,
  },
  {
    id: "kurumsal",
    no: "03",
    name: "Kurumsal",
    subtitle: "Uçtan uca ihracat",
    description: "Analiz, sunum ve operasyon başlıklarını birlikte yürütmek isteyen firmalar için bütünleşik çalışma.",
    features: ["Büyüme kapsamına ek olarak", "Gümrük müşavirliği", "Lojistik & nakliye müşavirliği", "Süreç & belge danışmanlığı", "Marka & ambalaj danışmanlığı"],
    idealFor: "Birden fazla hizmeti tek plan altında koordine etmek isteyen firmalar",
  },
];

export const pricingNote =
  "Fiyatlar firmalara özel yapılan analizlere göre değişir. Paket kapsamları örnektir; kesin içerik ve ücret, firmanızın ihtiyacı değerlendirildikten sonra tekliflendirilir.";

export const process = [
  { no: "01", title: "Tanışma & ihtiyaç", detail: "Ürününüzü, hedef pazarınızı ve beklentinizi dinliyoruz. Hangi hizmetlerin gerçekten gerekli olduğunu birlikte netleştiriyoruz.", duration: "İlk görüşme" },
  { no: "02", title: "Firma analizi", detail: "Ürün, pazar, rekabet, fiyat ve operasyon başlıklarını firmanızın yapısına göre değerlendiriyoruz.", duration: "Kapsama göre" },
  { no: "03", title: "Özel teklif", detail: "Size uygun paket veya hizmet kapsamını, teslimatları ve çalışma takvimini yazılı olarak sunuyoruz.", duration: "Analiz sonrası" },
  { no: "04", title: "Uygulama & takip", detail: "Onaylanan kapsamı ilgili ekip arkadaşlarımızla yürütüyor, gelişmeleri sizinle düzenli paylaşıyoruz.", duration: "Planlanan takvim" },
];

export const values = [
  { title: "Firmaya özel yaklaşım", detail: "Her firmanın ürünü, pazarı ve ihtiyacı farklıdır. Kapsamı ve fiyatı bu ihtiyaca göre belirliyoruz." },
  { title: "Analizden operasyona", detail: "Araştırma, tasarım ve saha operasyonunu ayrı ayrı değil, birbirini tamamlayan adımlar olarak ele alıyoruz." },
  { title: "Üç ofisle saha iletişimi", detail: "Gana, Suudi Arabistan ve Suriye ofislerimizle hedef bölgelerdeki iletişimi ve koordinasyonu destekliyoruz." },
  { title: "Şeffaf kapsam", detail: "Nelerin yapılacağını, kimin yürüteceğini ve hangi takvimle ilerleyeceğini teklif aşamasında netleştiriyoruz." },
];

export const team = [
  { name: "Devran Taşpınar", role: "Şirket Kurucusu", initials: "DT", bio: "Pazera’nın kurucusu olarak firmaların ihracat yolculuğunda analizden operasyona uzanan çalışma yaklaşımını yönlendirir.", tags: ["Kurucu", "İhracat", "Yönlendirme"], founder: true },
  { name: "Zeynep Kaya", role: "Pazar Araştırması & Ürün Analizi", initials: "ZK", bio: "Ürün, pazar, rakip ve fiyat analizi başlıklarında firmaların hedeflerine uygun araştırma kapsamını planlar.", tags: ["Araştırma", "Analiz"] },
  { name: "Elif Demir", role: "Lojistik & Nakliye Danışmanlığı", initials: "ED", bio: "Taşıma, sevkiyat ve lojistik akışlarının değerlendirilmesi ve operasyon koordinasyonunda görev alır.", tags: ["Lojistik", "Nakliye"] },
  { name: "Sude Arslan", role: "Web Site & Katalog Tasarımı", initials: "SA", bio: "Firmaların dijital vitrini ve ürün sunumlarını anlaşılır, tutarlı ve erişilebilir bir yapıda tasarlar.", tags: ["Web", "Katalog"] },
  { name: "Ayşe Yılmaz", role: "Müşteri İletişimi & İş Geliştirme", initials: "AY", bio: "İlk görüşme, ihtiyaç aktarımı ve ilgili ekip arkadaşına yönlendirme süreçlerinde firmalara eşlik eder.", tags: ["İletişim", "İş geliştirme"] },
];

export const sectors = [
  { name: "Üretim & İmalat", detail: "Ürününü yurt dışına açmak isteyen üreticiler.", image: "https://images.pexels.com/photos/31212947/pexels-photo-31212947.jpeg?auto=compress&cs=tinysrgb&w=1000" },
  { name: "Tüketim Ürünleri", detail: "Raf, ambalaj ve alıcı sunumu önemli olan markalar.", image: "https://images.pexels.com/photos/11678431/pexels-photo-11678431.jpeg?auto=compress&cs=tinysrgb&w=1000" },
  { name: "Toptan Ticaret", detail: "Ürün portföyünü yeni pazarlara taşımak isteyen firmalar.", image: "https://images.pexels.com/photos/30824313/pexels-photo-30824313.jpeg?auto=compress&cs=tinysrgb&w=1000" },
];

export type Article = {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
  author: string;
  intro: string;
  sections: { heading: string; paragraphs: string[]; bullets?: string[] }[];
};

export const articles: Article[] = [
  {
    slug: "ihracatta-urun-analizi",
    title: "İhracata başlamadan önce ürün analizi neden önemli?",
    excerpt: "Ürününüzün güçlü yönlerini, hedef pazar beklentilerini ve geliştirme önceliklerini nasıl birlikte okursunuz?",
    category: "Analiz",
    date: "12 Ocak 2026",
    readTime: "5 dk",
    image: "https://images.pexels.com/photos/31212947/pexels-photo-31212947.jpeg?auto=compress&cs=tinysrgb&w=1600",
    author: "Zeynep Kaya",
    intro: "İhracat hazırlığında ilk soru çoğu zaman ‘hangi ülkeye satmalıyım?’ olur. Oysa daha temel bir soru vardır: ürünüm bu pazarda hangi ihtiyaca karşılık geliyor?",
    sections: [
      { heading: "Ürünü özellikten çok ihtiyaçla okuyun", paragraphs: ["Teknik özellikler önemlidir; ancak alıcının kararını çoğu zaman kullanım kolaylığı, teslim güvenilirliği, ambalaj ve toplam maliyet gibi başlıklar etkiler. Ürün analizinde bu başlıkları birlikte ele almak gerekir."] },
      { heading: "Hedef pazar beklentisini karşılaştırın", paragraphs: ["Aynı ürün farklı pazarlarda farklı beklentilerle karşılaşabilir. Ambalaj dili, birim düzeni, sunum biçimi ve dağıtım kanalı bu beklentinin parçasıdır."], bullets: ["Ürünün kullanım alanını netleştirin", "Hedef müşteri profilini tanımlayın", "Ambalaj ve sunum dilini gözden geçirin", "Geliştirme önceliklerini sıralayın"] },
      { heading: "Analizi bir sonraki adıma bağlayın", paragraphs: ["Ürün analizi tek başına bir rapor olarak kalmamalı. Pazar araştırması, fiyat çalışması ve sunum hazırlığı için yol gösterici bir başlangıç olmalıdır."] },
    ],
  },
  {
    slug: "uc-ofis-uc-pazar",
    title: "Gana, Suudi Arabistan ve Suriye: pazara hazırlıkta ilk başlıklar",
    excerpt: "Üç farklı bölgede iş geliştirmeye hazırlanan firmaların araştırma, iletişim ve operasyon planında neleri netleştirmesi gerekir?",
    category: "Pazar Araştırması",
    date: "8 Ocak 2026",
    readTime: "6 dk",
    image: "https://images.pexels.com/photos/38096888/pexels-photo-38096888.jpeg?auto=compress&cs=tinysrgb&w=1600",
    author: "Devran Taşpınar",
    intro: "Pazera’nın Gana, Suudi Arabistan ve Suriye ofisleri, farklı bölgelerdeki ticari iletişimin koordinasyonuna katkı sağlar. Her pazar için aynı hazırlık sırasını kullanmak yerine ürün ve hedefe göre çalışmak daha sağlıklıdır.",
    sections: [
      { heading: "Önce ürün-pazar uyumu", paragraphs: ["Her ülkede ürününüzün hangi müşteri grubuna hitap ettiğini, hangi kanaldan sunulacağını ve nasıl bir fiyat algısı oluşabileceğini araştırın. Genel ülke bilgisi yerine ürününüze özel sorulara odaklanın."] },
      { heading: "İletişim ve sunum dilini hazırlayın", paragraphs: ["Web sitesi, katalog ve teklif dili alıcının sizi doğru anlamasını sağlar. Ürün bilgileri, ölçü birimleri ve iletişim kanalları tutarlı olmalıdır."] },
      { heading: "Operasyonu baştan planlayın", paragraphs: ["Teslim şekli, taşıma modeli, belge akışı ve ödeme yaklaşımı pazara göre değişebilir. Bu başlıkları ilk tekliften önce netleştirmek sonradan yaşanabilecek belirsizlikleri azaltır."], bullets: ["Hedef müşteri ve kanal araştırması", "Ürün ve fiyat değerlendirmesi", "Çok dilli sunum hazırlığı", "Lojistik, nakliye ve belge planı"] },
    ],
  },
  {
    slug: "lojistik-nakliye-maliyetleri",
    title: "Lojistik ve nakliye planında hangi maliyet kalemleri vardır?",
    excerpt: "Navlun dışında depolama, elleçleme, teslim şekli ve zamanlama gibi kalemlerin toplam maliyete etkisini ele alıyoruz.",
    category: "Operasyon",
    date: "22 Aralık 2025",
    readTime: "5 dk",
    image: "https://images.pexels.com/photos/6595780/pexels-photo-6595780.jpeg?auto=compress&cs=tinysrgb&w=1600",
    author: "Elif Demir",
    intro: "Sevkiyat maliyetini yalnızca navlun teklifi üzerinden okumak, toplam bütçenin bir kısmını görmeye benzer. Lojistik ve nakliye kararlarını birlikte değerlendirmek gerekir.",
    sections: [
      { heading: "Taşıma modeli ve rota", paragraphs: ["Kara, deniz, hava veya çoklu taşıma seçenekleri yükün özelliklerine ve teslim beklentisine göre karşılaştırılır. En hızlı seçenek her zaman en uygun toplam maliyet anlamına gelmez."] },
      { heading: "Navlun dışındaki kalemler", paragraphs: ["Depolama, elleçleme, iç nakliye, belge hazırlığı ve teslim noktasındaki sorumluluklar toplam maliyeti etkileyebilir. Teklifte hangi kalemlerin dahil olduğunu netleştirin."], bullets: ["Çıkış ve varış noktası", "Teslim şekli ve sorumluluk paylaşımı", "Yükleme/boşaltma koşulları", "Bekleme ve ek hizmet ihtimalleri"] },
      { heading: "Planı teklifle uyumlayın", paragraphs: ["Fiyat analizinde kullanılan teslim varsayımı ile nakliye planı aynı olmalıdır. Aksi halde teklif edilen marj operasyon sırasında değişebilir."] },
    ],
  },
  {
    slug: "web-site-katalog-guveni",
    title: "Web sitesi ve katalog, yurt dışındaki alıcıya nasıl güven verir?",
    excerpt: "Tutarlı ürün bilgisi, açık iletişim ve düzenli sunumla dijital vitrininizi güçlendirmenin temel yolları.",
    category: "Tasarım",
    date: "10 Aralık 2025",
    readTime: "4 dk",
    image: "https://images.pexels.com/photos/36765718/pexels-photo-36765718.jpeg?auto=compress&cs=tinysrgb&w=1600",
    author: "Sude Arslan",
    intro: "Bir alıcı firmanızla ilk kez karşılaştığında web siteniz ve kataloğunuz çoğu zaman ilk izlenimi oluşturur. Bu iki alanın aynı bilgiyi, aynı düzenle anlatması önemlidir.",
    sections: [
      { heading: "Bilgiyi kolay bulunabilir yapın", paragraphs: ["Ürün grupları, teknik bilgiler, iletişim ve teklif adımları açık bir yapıda sunulmalıdır. Ziyaretçi aradığı bilgiye fazla adım geçmeden ulaşabilmelidir."] },
      { heading: "Görsel ve metin tutarlılığı kurun", paragraphs: ["Katalogdaki ürün adı ile sitedeki ürün adı aynı olmalı; ölçü birimleri ve açıklamalar birbiriyle uyumlu ilerlemelidir."], bullets: ["Mobil uyumlu sayfalar", "Anlaşılır ürün görselleri", "Tutarlı teknik bilgiler", "Kolay iletişim ve WhatsApp bağlantısı"] },
      { heading: "Güncel kalacak bir yapı seçin", paragraphs: ["Ürün portföyü değiştikçe site ve katalog da güncellenebilmelidir. Tasarım kararlarını bu sürdürülebilirlikle birlikte almak uzun vadede işinizi kolaylaştırır."] },
    ],
  },
];

export const faqs = [
  { q: "Kaç yıldır ihracatın içindesiniz?", a: "Pazera olarak 5 yıldır ihracatın içindeyiz ve 100 firma ile çalışıyoruz. Çalışmalarımızı ürün/pazar analizi, operasyon danışmanlığı ve tasarım başlıklarında yürütüyoruz." },
  { q: "Ofisleriniz nerede?", a: "Gana, Suudi Arabistan ve Suriye olmak üzere 3 ofisimiz bulunuyor. Adres ve ziyaret bilgileri için WhatsApp veya iletişim formu üzerinden ekibimizle görüşebilirsiniz." },
  { q: "Hizmet paketlerinin fiyatı nedir?", a: "Fiyatlar firmalara özel yapılan analizlere göre değişir. Başlangıç, Büyüme ve Kurumsal olmak üzere 3 hizmet paketimiz vardır; kapsam ve ücret ihtiyacınız değerlendirildikten sonra teklif edilir." },
  { q: "Sadece tek bir hizmet alabilir miyim?", a: "Evet. Paket dışında, ihtiyacınız olan tek hizmet için de görüşebiliriz. Örneğin yalnızca katalog tasarımı, fiyat analizi veya nakliye müşavirliği talep edebilirsiniz." },
  { q: "Devran Taşpınar ile nasıl görüşebilirim?", a: "İletişim formuna talebinizi bırakabilir veya 0546 401 28 83 numarasından WhatsApp üzerinden yazabilirsiniz. Talebiniz ilgili ekip arkadaşına yönlendirilir." },
  { q: "Gümrük müşavirliği kapsamında neler var?", a: "İşlem ve belge akışı, ürün bazlı süreç değerlendirmesi ve operasyon koordinasyonu dosya özelinde ele alınır. Gerekli yetki ve temsil koşulları teklif aşamasında netleştirilir." },
];
