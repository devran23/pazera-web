import {
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  company: varchar("company", { length: 180 }),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 60 }),
  country: varchar("country", { length: 120 }),
  service: varchar("service", { length: 160 }),
  packageName: varchar("package_name", { length: 40 }),
  volume: varchar("volume", { length: 120 }),
  message: text("message"),
  source: varchar("source", { length: 60 }).notNull().default("website"),
  status: varchar("status", { length: 30 }).notNull().default("yeni"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const subscribers = pgTable("subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  source: varchar("source", { length: 60 }).notNull().default("footer"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const readinessChecks = pgTable("readiness_checks", {
  id: serial("id").primaryKey(),
  company: varchar("company", { length: 180 }),
  email: varchar("email", { length: 200 }),
  score: integer("score").notNull(),
  level: varchar("level", { length: 40 }).notNull(),
  focus: varchar("focus", { length: 200 }),
  answers: jsonb("answers").$type<Record<string, number>>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Lead = typeof leads.$inferSelect;
export type NewLead = typeof leads.$inferInsert;
export type Subscriber = typeof subscribers.$inferSelect;
export type ReadinessCheck = typeof readinessChecks.$inferSelect;
