import path from "node:path";
import { sql } from "drizzle-orm";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { db } from "@/db";

let ready: Promise<void> | undefined;

/**
 * Apply the checked-in, additive migrations once per server process.
 * A transaction-scoped PostgreSQL advisory lock serializes concurrent cold starts.
 * The initial SQL is idempotent so an existing database created by `push` is preserved.
 */
export function ensureDatabaseReady(): Promise<void> {
  if (!ready) {
    ready = db
      .transaction(async (tx) => {
        await tx.execute(sql`SELECT pg_advisory_xact_lock(72831001)`);
        await migrate(tx, {
          migrationsFolder: path.join(process.cwd(), "drizzle"),
        });
      })
      .catch((error: unknown) => {
        ready = undefined;
        throw error;
      });
  }
  return ready;
}
