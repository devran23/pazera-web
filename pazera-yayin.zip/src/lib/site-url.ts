/** Canonical public origin. Explicit setting wins; Vercel provides a safe default. */
export function getSiteUrl(): string {
  const explicit = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  const vercelProduction = process.env.VERCEL_PROJECT_PRODUCTION_URL?.trim();
  const vercelDeployment = process.env.VERCEL_URL?.trim();
  const automatic = vercelProduction || vercelDeployment;
  const candidate =
    explicit ||
    (automatic ? `https://${automatic.replace(/^https?:\/\//, "")}` : undefined) ||
    (process.env.NODE_ENV === "development" ? "http://localhost:3000" : "https://pazera.com");

  try {
    const url = new URL(candidate);
    if (url.protocol !== "https:" && url.protocol !== "http:") {
      return "https://pazera.com";
    }
    return url.origin;
  } catch {
    return "https://pazera.com";
  }
}
