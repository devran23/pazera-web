# Pazera — komut yazmadan yayın rehberi

Bu proje Next.js + PostgreSQL kullanır. Önerilen yayın: **Vercel + Neon**. GitHub yalnızca dosyaları Vercel’e aktarmak için kullanılır.

**Önemli:** Bu rehber ve `/yayin` ekranı hesaplarınıza bağlanmaz, ödeme yapmaz ve kendi kendine yayın başlatmaz. Hesap açma/onay işlemleri hesap sahibinde kalır. Şifre/token paylaşmayın.

## En kolay yol

### 1. Paketi indirin
Önizleme adresinin sonuna `/yayin` ekleyin. Örneğin:

`https://ONIZLEME-ADRESINIZ/yayin`

İlk adımdaki **Proje ZIP’ini indir** düğmesini kullanın. ZIP bilgisayarınızda açın.

Paket şunları içerir:
- site kodu (`src`, `public/brand`)
- `package.json`, `package-lock.json`
- Next.js/TypeScript/Drizzle ayarları
- otomatik veritabanı kurulum dosyaları (`drizzle`)
- `.env.example`, `.gitignore`

Paket şunları içermez:
- gerçek `.env` dosyası
- örnek müşteri kayıtları / veritabanı dökümü
- `node_modules`, `.next`, `.vercel`

### 2. GitHub’a yükleyin
1. https://github.com/new adresinde özel (private) bir depo oluşturun; örneğin `pazera-web`.
2. Boş depo sayfasında **uploading an existing file / upload files** bağlantısını açın.
3. ZIP’den çıkan **klasörleri ve dosyaları** sürükleyin. Sadece ZIP dosyasını yüklemeyin; içindeki `src`, `public`, `drizzle` klasörleri ve kök dosyalar depo kökünde olmalı.
4. **Commit changes** deyin.

`.env` yüklemeyin. `.env.example` ve `.gitignore` görünmüyorsa sorun değil; gerçek gizli değerler zaten Vercel’e girilecek.

### 3. Vercel’e aktarın
1. https://vercel.com/new adresine girin.
2. GitHub hesabınızı bağlayın.
3. `pazera-web` deposunu **Import** edin.
4. Framework **Next.js** kalsın. Root Directory depo kökü olsun.
5. Build Command `npm run build`, Output ayarı Next.js varsayılanı kalsın. `out` seçmeyin.
6. Node.js sürümünü **22.x** seçin.

Henüz Deploy demeden veritabanını bağlayın.

### 4. Neon veritabanını bağlayın
Vercel projenizde **Storage / Integrations → Neon Postgres** yolunu izleyin. Neon’u ekleyip Vercel projesine bağlayın. Bölge ve plan seçimini kendi hesabınızda onaylayın.

Bu bağlantı `DATABASE_URL` değişkenini otomatik ekler. Elle bağlantı adresi kopyalamanız gerekmez.

Resmî rehber: https://neon.com/docs/guides/vercel-managed-integration

### 5. Panel şifrelerini ekleyin
`/yayin` ekranındaki 5. adımda **Güvenli değerleri üret** düğmesine basın.

Vercel → **Settings → Environment Variables** bölümünde **Production** için şu iki anahtarı ekleyin:

| Anahtar | Değer |
| --- | --- |
| `ADMIN_PASSWORD` | Ekranda üretilen panel şifresi |
| `ADMIN_SESSION_SECRET` | Ekranda üretilen ayrı oturum anahtarı |

Değerleri Kopyala düğmesiyle alın. Bu değerler tarayıcıda kalıcı saklanmaz; Vercel’e eklemeden sekmeyi kapatmayın.

`NEXT_PUBLIC_SITE_URL` ilk yayın için zorunlu değildir. Vercel kendi proje adresini otomatik kullanır. Özel alan adı bağlayınca isterseniz bu değişkeni `https://alan-adiniz.com` olarak ekleyip yeniden yayınlayın.

### 6. Deploy deyin
Vercel **Deploy** düğmesi siteyi yayınlar ve `proje-adi.vercel.app` gibi bir adres verir.

Veritabanı tabloları sunucu ilk açılırken **otomatik** oluşturulur. Terminal veya `drizzle-kit push` çalıştırmanız gerekmez. Kurulum mevcut kayıtları silmez; eşzamanlı başlangıçlar PostgreSQL kilidiyle sıraya alınır.

### 7. Kontrol edin
- `/api/health` → `{"ok":true}`
- Ana sayfa, hizmetler ve paketler açılıyor.
- WhatsApp `0546 401 2883` numarasına gidiyor.
- İletişim formu kayıt oluşturuyor.
- `/panel` şifre istiyor; şifresiz müşteri listesi görünmüyor.

### 8. Alan adı bağlayın
Alan adınız varsa Vercel → **Settings → Domains** bölümüne ekleyin. Vercel’in gösterdiği DNS kayıtlarını alan adı firmanızın paneline girin. E-posta MX kayıtlarını silmeyin. HTTPS otomatik hazırlanır.

Resmî rehber: https://vercel.com/docs/domains/set-up-custom-domain

## Takıldığınızda

- **Form kaydetmiyor:** Neon bağlantısını ve `/api/health` sonucunu kontrol edin.
- **Panel açılmıyor:** İki ortam değişkeninin Production’a eklendiğini ve sonra yeniden yayınlandığını kontrol edin.
- **Dosya bulunamadı hatası:** GitHub’da `package.json` depo kökünde mi, ZIP’in kendisi mi yüklendi kontrol edin.
- **Alan adı açılmıyor:** Vercel Domains ekranındaki DNS doğrulamasını kontrol edin.

## Notlar

- Formlar veritabanına yazar; otomatik e-posta/WhatsApp bildirimi göndermez.
- Önizlemedeki örnek kayıtlar yeni yayına taşınmaz.
- Gerçek ekip/ofis bilgilerini ve gizlilik/KVKK metinlerini yayından önce gözden geçirin.
- Hesap planları, limitler ve alan adı ücretleri sağlayıcıya göre değişir.

## Geliştiriciye teslim

Projeyi bir geliştiriciye teslim edecekseniz ZIP yeterlidir. Gizli değerleri ZIP’e koymayın; geliştirici kendi Vercel/Neon ortam değişkenlerini oluştursun. Hesap şifrenizi paylaşmayın.
