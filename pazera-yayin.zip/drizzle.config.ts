import "dotenv/config";
import { defineConfig } from "drizzle-kit";

const url = process.env.DATABASE_MIGRATION_URL || process.env.DATABASE_URL;
if (!url) {
  throw new Error("DATABASE_URL or DATABASE_MIGRATION_URL is required for schema operations.");
}

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: { url },
  verbose: true,
  strict: true,
});
