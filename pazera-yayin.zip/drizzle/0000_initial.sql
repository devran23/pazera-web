CREATE TABLE IF NOT EXISTS "leads" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(160) NOT NULL,
	"company" varchar(180),
	"email" varchar(200) NOT NULL,
	"phone" varchar(60),
	"country" varchar(120),
	"service" varchar(160),
	"package_name" varchar(40),
	"volume" varchar(120),
	"message" text,
	"source" varchar(60) DEFAULT 'website' NOT NULL,
	"status" varchar(30) DEFAULT 'yeni' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "leads" ADD COLUMN IF NOT EXISTS "package_name" varchar(40);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "readiness_checks" (
	"id" serial PRIMARY KEY NOT NULL,
	"company" varchar(180),
	"email" varchar(200),
	"score" integer NOT NULL,
	"level" varchar(40) NOT NULL,
	"focus" varchar(200),
	"answers" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "subscribers" (
	"id" serial PRIMARY KEY NOT NULL,
	"email" varchar(200) NOT NULL,
	"source" varchar(60) DEFAULT 'footer' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "subscribers_email_unique" UNIQUE("email")
);
